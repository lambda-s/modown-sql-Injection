<?php get_header();?>
<div class="banner-archive" <?php if(_MBT('banner_archive_img')){?> style="background-image: url(<?php echo _MBT('banner_archive_img');?>);" <?php }?>>
	<div class="container">
		<h1 class="archive-title"><?php echo _MBT('question_name')?_MBT('question_name'):__('问答','mobantu');?></h1>
		<p class="archive-desc"><?php echo _MBT('question_desc');?></p>
	</div>
</div>
<div class="main">
	<?php do_action("modown_main");?>
	<div class="container clearfix">
		<div class="content-wrap">
	    	<div class="content">
				<?php MBThemes_ad('ad_list_header');?>
				<div class="list-question-new"><span class="tit"><?php echo __("最新问题","mobantu");?></span><a href="<?php echo get_permalink(MBThemes_page("template/ask.php"));?>" class="btn"><?php echo __('我要提问','mobantu');?></a></div>
				<div id="posts" class="lists clearfix">
					<?php 
						if ( have_posts() ){
							while ( have_posts() ) : the_post(); 
							get_template_part( 'module/content-question' );
							endwhile; wp_reset_query(); 
						}else{
		                    get_template_part( 'module/none' );
		                }
					?>
				</div>
				<?php MBThemes_paging();?>
				<?php MBThemes_ad('ad_list_footer');?>
			</div>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<?php get_footer();?>