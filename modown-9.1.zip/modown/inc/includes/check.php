<?php
require( dirname(__FILE__).'/../../../../../wp-load.php' );
if(isset($_POST['action']) && current_user_can('administrator')){
	if($_POST['action'] == 'check'){
		$v = get_url_contents(base64_decode("aHR0cDovL2FwaS5tb2JhbnR1LmNvbS90aGVtZS9tb2Rvd24ucGhw"));
		if($v > THEME_VER){
			$arr=array(
				"status"=>1
			); 
		}else{
			$arr=array(
				"status"=>0
			);
		}
		$jarr=json_encode($arr); 
		echo $jarr;
	}elseif($_POST['action'] == 'restart'){
		$otheme = $_POST['theme'];
		delete_option('MBT_'.$otheme.'_token');
		delete_option('MBT_'.$otheme.'_options');
		delete_option('MBT_'.$otheme.'_version');
		$arr=array(
			"status"=>1
		);
		$jarr=json_encode($arr); 
		echo $jarr;
	}
}