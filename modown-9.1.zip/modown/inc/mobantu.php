<?php
if (is_admin()) {
    define('OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/');
    require_once THEME_DIR . '/inc/options-framework.php';
    require_once THEME_DIR . '/inc/options.php';
}
require_once THEME_DIR . '/inc/init.php';
require_once THEME_DIR . '/inc/base.php';
