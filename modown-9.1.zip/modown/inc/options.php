<?php
function optionsframework_option_name() {
    return 'Modown';
}
function optionsframework_options() {
    $multicheck_defaults = array(
        'one' => '1',
        'five' => '1'
    );
    $background_defaults = array(
        'color' => '',
        'image' => '',
        'repeat' => 'repeat',
        'position' => 'top center',
        'attachment'=>'scroll' );
    $typography_defaults = array(
        'face' => 'yahei',
        'style' => 'normal',
        'color' => '#383121' );
    $typography_content = array(
        'size' => '13px',
        'face' => 'yahei',
        'style' => 'normal',
        'color' => '#000000' );
    $typography_options = array(
        'sizes' => false
    );
    $wp_editor_settings = array(
        'wpautop' => true, // Default
        'textarea_rows' => 5,
        'tinymce' => array( 'plugins' => 'wordpress,wplink' )
    );
    $options_categories = array();
    $options_categories_obj = get_categories();
    foreach ($options_categories_obj as $category) {
        $options_categories[$category->cat_ID] = $category->cat_name;
    }
    $options_pages = array();
    $options_pages_obj = get_pages('sort_column=post_parent,menu_order');
    foreach ($options_pages_obj as $page) {
        $options_pages[$page->ID] = $page->post_title;
    }
    $adsdesc =  '可添加广告联盟代码或自定义代码';
    $qrcode = get_stylesheet_directory_uri() . '/static/img/qrcode.png';
    $logo = get_stylesheet_directory_uri() . '/static/img/logo.png';
    $favicon = get_stylesheet_directory_uri() . '/static/img/favicon.ico';
    $ops = array();
    $ops[] = array(
        'name' => '基本',
        'type' => 'heading',
    );



    $ops[] = array(
        'name' => 'Favicon图标',
        'id' => 'favicon',
        'desc' => '',
        'std' => get_bloginfo('template_directory').'/static/img/favicon.ico',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '可进后台角色',
        'desc' => '可进入后台的用户角色，高角色拥有低角色的权限，这里的角色是基于角色特有的权限来判断的',
        'id' => 'admin_capability',
        'options' => array(
            'activate_plugins' => '管理员',
            'delete_others_pages' =>'编辑',
            'delete_published_posts' => '作者',
            'scale-delete_posts' => '贡献者',
        ),
        'type' => 'select',
        'std' => 'delete_others_pages',
    );
    $ops[] = array(
        'name' => '隐藏登录注册/付费/评论',
        'id' => 'hide_user_all',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（<b>请勿随意勾选！</b>隐藏网站所有与用户、付费、VIP、评论相关的内容，登录后可见）',
    );
    $ops[] = array(
        'name' => '禁用主题SEO',
        'id' => 'seo',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '禁用（禁用后将不再显示主题自带的keywords与description信息，使用了独立的SEO插件的站可以禁用以免信息重复）',
    );
    $ops[] = array(
        'name' => '右贴边导航',
        'id' => 'rollbar',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '显示（用于显示客服、夜间切换、繁简切换、返回顶部等）',
    );
    $ops[] = array(
        'name' => '右贴边手机端',
        'id' => 'rollbar_wap',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（当手机端显示底部导航时，右贴边默认隐藏）',
    );
    $ops[] = array(
        'name' => '全屏切换',
        'id' => 'fullscreen',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示',
    );
    $ops[] = array(
        'name' => '客服QQ链接',
        'id' => 'kefu_qq',
        'type' => 'text',
        'std' => 'http://wpa.qq.com/msgrd?v=3&uin=2533656982&site=qq&menu=yes',
        'desc' => 'http://wpa.qq.com/msgrd?v=3&uin=2533656982&site=qq&menu=yes',
    );
    $ops[] = array(
        'name' => '客服微信二维码',
        'id' => 'kefu_weixin',
        'desc' => '',
        'std' => 'https://vkceyugu.cdn.bspapp.com/VKCEYUGU-e7ffe27f-d6d5-4e22-9842-dff6b08def0c/a6567c63-4a24-4989-ac7e-993be11541ed.jpg',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => 'QQ微信防红',
        'id' => 'tencent_block',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（在域名未被拦截的情况下，通过QQ、微信访问会提示用默认浏览器打开）',
    );
    $ops[] = array(
        'name' => '前台禁止右键',
        'id' => 'frontend_copy',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（对非管理员有效）',
    );
    $ops[] = array(
        'name' => '维护模式',
        'id' => 'maintenance',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（前台所有页面提示正在维护中）',
    );

    $ops[] = array(
        'name' => '维护模式提示',
        'desc' => '支持html，如需a标签为按钮样式可给a标签加class为btn',
        'id' => 'maintenance_tips',
        'std' => '',
        'type' => 'editor',
        'settings' => $wp_editor_settings
    );
    $ops[] = array(
        'name' => '上传文件重命名',
        'id' => 'file_rename',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（该功能会针对上传的文件和图片重命名，如：09075549994.jpg）',
    );
    $ops[] = array(
        'name' => '无限下拉自动分页',
        'id' => 'ajax_list_load',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（页面下拉到一定位置自动加载下一页）',
    );
    $ops[] = array(
        'name' => '图片延迟加载',
        'id' => 'lazyload',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启 （文章列表图片延迟加载，给网站提速）',
    );
    $ops[] = array(
        'name' => '移动端缩略图自适应',
        'id' => 'thumbnail_auto',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用（如果你的图片尺寸都是统一固定大小的，可以启用，否则不要启用）',
    );
    $ops[] = array(
        'name' => __('缩略图BFIThumb剪切'),
        'id' => 'bfithumb',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('开启（不支持外链！使用主题自带的BFI_Thumb.php剪切，需要wp-content目录有可写入权限，会生成一个cache文件夹，若发现启用后无法显示图片，请检查wp-content/cache目录权限，可设置成755，不开启则使用系统自带的剪切，记得在 设置-媒体 里调整下缩略图大小的尺寸，系统自带的剪切仅支持上传设置了特色图片）'),
    );
    $ops[] = array(
        'name' => __('缩略图Timthumb剪切'),
        'id' => 'timthumb',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('开启（若启用了缩略图BFIThumb剪切，则不生效！使用主题自带的timthumb.php剪切，需要wp-content目录有可写入权限，会生成一个cache文件夹，若发现启用后无法显示图片，请检查wp-content/cache目录权限，可设置成755，不开启则使用系统自带的剪切，记得在 设置-媒体 里调整下缩略图大小的尺寸，系统自带的剪切仅支持上传设置了特色图片。不启用则timthumb.php文件不会生效）'),
    );
    $ops[] = array(
        'name' => 'Timthumb剪切方式',
        'desc' => '默认居中剪切，部分情况可能需要用到顶部剪切',
        'id' => 'timthumb_type',
        'options' => array(
            'c' => '剧中裁剪',
            't' =>'顶部剪切',
            'b' => '底部剪切',
            'l' => '左边剪切',
            'r' => '右边剪切',
        ),
        'type' => 'select',
    );
    $ops[] = array(
        'name' => __('Timthumb支持外链'),
        'id' => 'timthumb_external',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('开启（是否让Timthumb支持外链，如果开启了，需设置下面的Timthumb外链域名，否则会出现外链缩略图无法显示）'),
    );
    $ops[] = array(
        'name' => __('Timthumb外链域名'),
        'id' => 'timthumb_domains',
        'type' => 'text',
        'desc' => __('<b>请确保外链图片的安全性</b>，不要用那种任何人都可以上传任何图片的外链！多个域名用英文半角逗号隔开，可精确到子域名，例如：mobantu.com,erphpdown.com,img.mobantu.com'),
    );
    $ops[] = array(
        'name' => '缩略图CDN剪切',
        'id' => 'timthumb_cdn',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（使用第三方CDN例如七牛、OSS等的剪切方式，需要在下面设置剪切后缀）',
    );
    $ops[] = array(
        'name' => 'CDN剪切样式后缀',
        'id' => 'timthumb_cdn_after',
        'type' => 'text',
        'std' => '',
        'desc' => '例如：?imageView2/1/w/285/h/180/q/90，这个是直接自动加在缩略图地址后面的',
    );
    $ops[] = array(
        'name' => '自定义预加载图片',
        'id' => 'thumbnail_loading',
        'std' => '',
        'type' => 'upload',
        'desc' => '开启延迟加载时，列表页的预加载图片，默认是灰色小飞机静态图片，可以自己上传个加载loading的动图',
    );
    $ops[] = array(
        'name' => '默认特色图片',
        'id' => 'thumbnail_default',
        'std' => '',
        'type' => 'upload',
        'desc' => '当文章没有设置任何图片时，列表页显示该默认图片',
    );
    $ops[] = array(
        'name' => '特色图片尺寸',
        'desc' => '当没有开启缩略图自动剪切时，文章列表显示的图片尺寸，尺寸设置可访问/wp-admin/options-media.php',
        'id' => 'post_related_in',
        'options' => array(
            'full' => '原图',
            'thumbnail' =>'缩略图大小',
            'medium' => '中等大小',
            'large' => '大尺寸',
        ),
        'type' => 'select',
    );
    $ops[] = array(
        'name' => '特色图片显示方式',
        'desc' => '可自行选择后看看前台文章列表图片的变化',
        'id' => 'post_related_in',
        'options' => array(
            'cover' => '剪裁适应',
            'fill' =>'拉伸适应',
            'contain' => '缩放填充',
            'scale-down' => '缩放填充原图',
            'none' => '原图',
        ),
        'type' => 'select',
    );
    $ops[] = array(
        'name' => '禁止生成缩略图',
        'id' => 'thumbnail',
        'type' => 'checkbox',
        'desc' => '禁止（禁止后上传到媒体库的图片将不会剪切生成各种尺寸的图片而占用空间资源，禁止此项的同时建议开启上面的缩略图自动剪切）',
    );
    $ops[] = array(
        'name' => '标题分割符',
        'id' => 'delimiter',
        'type' => 'text',
        'std' => '-',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '标题分割符去空格',
        'id' => 'delimiter_space',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '博客类型名称',
        'id' => 'blog_name',
        'type' => 'text',
        'std' => '博客',
        'desc' => '例如：教程',
    );
    $ops[] = array(
        'name' => '博客介绍',
        'id' => 'blog_desc',
        'type' => 'text',
        'std' => '这是模板兔发布的关于wordpress的技术教程',
        'desc' => '例如：教程',
    );
    $ops[] = array(
        'name' => '公告样式',
        'id' => 'site_tips_style',
        'options' => array(
            0 => '默认',
            1 => '弹窗',
        ),
        'std' => '0',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '公告',
        'desc' => '支持html，如需a标签为按钮样式可给a标签加class为btn',
        'id' => 'site_tips',
        'std' => '',
        'type' => 'editor',
        'settings' => $wp_editor_settings
    );
	
	$ops[] = array(
        'name' => '全站左下角推送随机文章购买记录',
        'id' => 'bought_barrage',
        'std' => '',
        'desc' => '全站左下角推送随机文章购买记录（主题设置-基本）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '页头',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '全宽',
        'id' => 'header_fullwidth',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（顶部LOGO菜单栏部分全宽）',
    );
    $ops[] = array(
        'name' => '飘逸',
        'id' => 'header_animated',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（页面下滑隐藏上滑显示）',
    );
    $ops[] = array(
        'name' => 'Logo',
        'id' => 'logo',
        'desc' => '建议尺寸：70*70px 建议格式：png',
        'std' => get_bloginfo('template_directory').'/static/img/logo.png',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => 'Logo夜间',
        'id' => 'logo_night',
        'desc' => '建议尺寸：70*70px 建议格式：png',
        'std' => get_bloginfo('template_directory').'/static/img/logo.png',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '手机端Logo',
        'id' => 'logo_mobile',
        'desc' => '建议尺寸：60*60px 建议格式：png',
        'std' => get_bloginfo('template_directory').'/static/img/logo.png',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '手机端Logo夜间',
        'id' => 'logo_mobile_night',
        'desc' => '建议尺寸：70*70px 建议格式：png',
        'std' => get_bloginfo('template_directory').'/static/img/logo.png',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => 'Logo宽度',
        'id' => 'logo_width',
        'type' => 'text',
        'std' => '70',
        'desc' => '像素，请根据LOGO大小的比例来，高度是70，建议不要设置超过180',
    );
    $ops[] = array(
        'name' => 'Logo手机端宽度',
        'id' => 'logo_width_wap',
        'type' => 'text',
        'std' => '60',
        'desc' => '像素，请根据LOGO大小的比例来，高度是60，建议不要设置超过180',
    );
    $ops[] = array(
        'name' => 'Logo扫光',
        'id' => 'logo_scan',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（只有顶部导航栏一直是白色背景时才建议开启，否则不要开启）',
    );
    $ops[] = array(
        'name' => '手机端LOGO位置',
        'id' => 'header_logo_position',
        'options' => array(
            0 => '左边',
            1 => '中间',
        ),
        'std' => '0',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '背景样式',
        'id' => 'header_type',
        'desc' => '',
        'options' => array(
            'default' => '默认（首页与列表页会透明显示，其他页为白色背景）',
            'light' => '白色背景',
            'dark' => '黑色背景',
            'custom' => '在下面自定义',
        ),
        'std' => 'default',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '背景色',
        'id' => 'header_bgcolor',
        'desc' => '',
        'std' => '#ffffff',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '导航文字颜色',
        'id' => 'header_txtcolor',
        'desc' => '',
        'std' => '#062743',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '默认文字颜色',
        'id' => 'header_color',
        'desc' => '仅适用于背景样式为默认、首页显示Banner，避免当Banner图与文字颜色相近导致导航看不清',
        'std' => '#ffffff',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => 'VIP按钮',
        'id' => 'header_vip',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => 'VIP手机端按钮',
        'id' => 'header_vip_wap',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => 'VIP简介',
        'id' => 'header_vip_desc',
        'type' => 'text',
        'std' => '升级VIP享受精彩下载！',
        'desc' => '请简短介绍VIP权限，15字左右最佳，用于显示在已登录用户头像处',
    );
	$ops[] = array(
        'name' => '导航直接显示搜索框',
        'id' => 'header_search_nav',
        'std' => '',
        'desc' => '顶部导航可直接显示搜索框 (建议左侧导航不要过长,不然搜索框会挤到下一行) ',
        'type' => 'checkbox',
    );
	
    $ops[] = array(
        'name' => '通知按钮',
        'id' => 'header_notice',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '通知手机端按钮',
        'id' => 'header_notice_wap',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '投稿按钮',
        'id' => 'header_tougao',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '投稿手机按钮',
        'id' => 'header_tougao_wap',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '购物车按钮',
        'id' => 'header_cart',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（安装了woocommerce插件后的购物车页面）',
    );
    $ops[] = array(
        'name' => '购物车手机按钮',
        'id' => 'header_cart_wap',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '隐藏搜索',
        'id' => 'header_search',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（隐藏顶部导航栏的搜索按钮）',
    );
    $ops[] = array(
        'name' => '隐藏登录注册',
        'id' => 'header_login',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（隐藏顶部导航栏的登录注册按钮，不影响已登录用户的头像显示）',
    );
    $ops[] = array(
        'name' => '自定义顶部代码',
        'id' => 'header_code',
        'type' => 'textarea',
        'std' => '',
        'desc' => '可以引用一些css、js，或者自定义代码',
    );
    $ops[] = array(
        'name' => '页脚',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '背景色',
        'id' => 'footer_bgcolor',
        'type' => 'button',
        'std' => '#333',
        'type' => 'color',
        'desc' => '颜色值',
    );
    $ops[] = array(
        'name' => '背景图',
        'id' => 'footer_bgimg',
        'std' => '',
        'type' => 'upload',
        'desc' => '若使用背景图，建议合理控制图片的色系，以便文字能更好的显示',
    );
    $ops[] = array(
        'name' => '友情链接',
        'id' => 'friendlink',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（后台左侧有个【链接】的菜单，进去添加友情链接，可分类）',
    );
    $ops[] = array(
        'name' => '友链分类ID',
        'id' => 'friendlink_id',
        'type' => 'text',
        'std' => '',
        'desc' => '首页只显示某个链接分类下的链接',
    );
    $ops[] = array(
        'name' => '导航不显示友链',
        'id' => 'friendlink_no',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（单独的导航页面里不显示上面设置的友链分类）',
    );
    $ops[] = array(
        'name' => '底部小工具',
        'id' => 'footer_widget',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '移动端隐藏小工具',
        'id' => 'footer_widget_hide',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '小工具列数',
        'id' => 'footer_widget_num',
        'desc' => '建议选4或者5，太少的话请确保你每列内容够宽',
        'options' => array(
            5 => '5列',
            4 => '4列',
            3 => '3列',
            2 => '2列',
        ),
        'std' => '4',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '移动端导航',
        'id' => 'footer_nav',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（手机端底部栏固定导航栏）',
    );
    $ops[] = array(
        'name' => '移动端导航个数',
        'id' => 'footer_nav_num',
        'options' => array(
            4 => '4列',
            5 => '5列',
        ),
        'std' => '4',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '移动端自定义导航',
        'desc' => '请填写html代码，导航最后一个“我的”不支持自定义，需要想去掉请用CSS隐藏即可',
        'id' => 'footer_nav_html',
        'std' => '',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '底部版权',
        'id' => 'copyright',
        'std' => '',
        'type' => 'editor',
        'settings' => $wp_editor_settings
    );
    $ops[] = array(
        'name' => '网站统计代码',
        'desc' => '位于底部，会被隐藏，但不影响统计效果',
        'id' => 'analysis',
        'std' => '',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '自定义底部代码',
        'desc' => '位于</body>之前，若是js代码需添加<script>标签',
        'id' => 'js',
        'std' => '',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '首页',
        'type' => 'heading',
    );
    
    
	
	$ops[] = array(
        'name' => '标题颠倒',
        'id' => 'home_title_exchange',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('开启（副标题在前，站点标题在后）'),
    );
    $ops[] = array(
        'name' => '关键字(keywords)',
        'id' => 'keywords',
        'std' => 'mobantu,wordpress主题定制',
        'desc' => '关键字有利于SEO优化，建议个数在5-10之间，用英文逗号隔开',
        'settings' => array(
            'rows' => 4,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '描述(description)',
        'id' => 'description',
        'std' => '专业提供wordpress主题定制开发服务',
        'desc' => '描述有利于SEO优化，建议字数在30-70之间',
        'settings' => array(
            'rows' => 4,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => 'Banner/幻灯片',
        'id' => 'banner',
        'options' => array(
            0 => '无',
            1 => 'Banner',
            2 => '幻灯片',
            3 => 'Banner+幻灯片',
        ),
        'std' => '1',
        'type' => 'select',
        'desc' => '可选择显示为一个大Banner或者幻灯片',
    );
    $ops[] = array(
        'name' => '首页幻灯片下公告ID',
        'id' => 'banner_bottom_notice',
        'type' => 'text',
        'std' => '',
        'desc' => '注意是博客分类的ID，不是文章分类ID',
    );
    $ops[] = array(
        'name' => __('幻灯片下搜索'),
        'id' => 'banner_bottom_search',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('启用（幻灯片下面位置的大搜索框，不是banner上的，banner上的搜索请到 主题设置-banner 里开启）'),
    );
    $ops[] = array(
        'name' => '分类图块ID',
        'id' => 'home_cats_thumb',
        'type' => 'text',
        'std' => '',
        'desc' => '首页的最新文章里不显示这些分类的文章，多个用半角英文逗号隔开，例如：1,3,12。<a href="https://www.mobantu.com/7616.html">如何查看ID</a>',
    );
    $ops[] = array(
        'name' => __('分类模块背景统一'),
        'id' => 'home_cats_bg',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('启用（对使用mocat短代码分类模块默认是白色和灰色交错显示，勾选后均显示为白色）'),
    );
    $ops[] = array(
        'name' => __('首页速成'),
        'id' => 'home_fast',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('启用（<b>仅对默认首页有效</b>，设置-阅读，您的主页显示 选 您的最新文章。速成的首页设置单一，无法对单个分类模块进行单独设置，建议用首页模板一）'),
    );
    $ops[] = array(
        'name' => __('首页速成-分类ID'),
        'id' => 'home_fast_cat',
        'type' => 'text',
        'std' => '',
        'desc' => __('默认首页显示多个分类模块。0表示最新发布，多个ID用半角英文逗号隔开，例如：0,1,3,12。<a href="https://www.mobantu.com/7616.html">如何查看ID</a>'),
    );
    $ops[] = array(
        'name' => __('首页速成-文章数'),
        'id' => 'home_fast_cat_num',
        'type' => 'text',
        'std' => '',
        'desc' => __('每个分类模块显示的文章数量，留空则默认8'),
    );
   
	$ops[] = array(
    'name' => '首页文章排序',
    'desc' => '选择首页文章的排序方式',
    'id' => 'home_orderby_modified',
    'desc' => __('（<b>仅对默认首页有效</b>，设置-阅读，您的主页显示 选 您的最新文章。如果使用的是首页模板一的mocat短代码，可加个orderby="modified"参数）'),
    'options' => array(
        '0' => '按发布时间排序（从新到旧）',
        '2' => '随机排序',
        '1' => '按修改时间排序（从新到旧）',
    ),
    'type' => 'select',
    'default' => '0',
);
	
    $ops[] = array(
        'name' => __('垂直锚点导航'),
        'id' => 'home_anchor',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('显示（<b>仅对使用首页模板一的首页有效</b>，即首页用多个mocat短代码组成模块，那么锚点可快速定位到指定模块）'),
    );
    $ops[] = array(
        'name' => '分类导航',
        'id' => 'home_cat',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（<b>仅对默认首页有效</b>，需设置分类菜单）',
    );
    $ops[] = array(
        'name' => '排除分类ID',
        'id' => 'home_cats_exclude',
        'type' => 'text',
        'std' => '',
        'desc' => '首页的最新文章里不显示这些分类的文章，多个用半角英文逗号隔开，例如：1,3,12。<a href="https://www.mobantu.com/7616.html">如何查看ID</a>',
    );
    $ops[] = array(
        'name' => '博客',
        'id' => 'home_blog',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（首页底部显示博客类型文章）',
    );
    $ops[] = array(
        'name' => '博客个数',
        'id' => 'home_blog_num',
        'type' => 'text',
        'std' => '6',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '作者推荐',
        'id' => 'home_authors',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（首页底部显示作者板块）',
    );
    $ops[] = array(
        'name' => '作者标题',
        'id' => 'home_author_title',
        'type' => 'text',
        'std' => '推荐作者',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '推荐作者IDs',
        'id' => 'home_author_ids',
        'type' => 'text',
        'std' => '',
        'desc' => '用户ID列表，多个用半角英文逗号隔开，例如：1,3,12。',
    );
    $ops[] = array(
        'name' => 'VIP',
        'id' => 'home_vip',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（首页底部显示VIP介绍）',
    );
    $ops[] = array(
        'name' => 'VIP标题',
        'id' => 'home_vip_title',
        'type' => 'text',
        'std' => '关于VIP',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势介绍',
        'id' => 'home_why',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（首页底部显示我们的优势）',
    );
    $ops[] = array(
        'name' => '手机端优势介绍',
        'id' => 'home_why_m',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '优势标题',
        'id' => 'home_why_title',
        'type' => 'text',
        'std' => '我们的优势',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势简介',
        'id' => 'home_why_desc',
        'type' => 'text',
        'std' => '资源丰富，专业人员筛选上传更新',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势一标题',
        'id' => 'home_why_title1',
        'type' => 'text',
        'std' => '更新及时',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势一简介',
        'id' => 'home_why_desc1',
        'type' => 'text',
        'std' => '专人上传，每天更新',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势一图标',
        'id' => 'home_why_icon1',
        'type' => 'text',
        'std' => 'arrow-thin-up',
        'desc' => '图标字体值请查看http://demo.amitjakhu.com/dripicons/',
    );
    $ops[] = array(
        'name' => '优势二标题',
        'id' => 'home_why_title2',
        'type' => 'text',
        'std' => '精选资源',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势二简介',
        'id' => 'home_why_desc2',
        'type' => 'text',
        'std' => '各类资源，满足需求',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势二图标',
        'id' => 'home_why_icon2',
        'type' => 'text',
        'std' => 'archive',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势三标题',
        'id' => 'home_why_title3',
        'type' => 'text',
        'std' => '高速下载',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势三简介',
        'id' => 'home_why_desc3',
        'type' => 'text',
        'std' => '专属网盘，极速体验',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势三图标',
        'id' => 'home_why_icon3',
        'type' => 'text',
        'std' => 'download',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势四标题',
        'id' => 'home_why_title4',
        'type' => 'text',
        'std' => '7x24h服务',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势四简介',
        'id' => 'home_why_desc4',
        'type' => 'text',
        'std' => '专人客服，随时联系',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '优势四图标',
        'id' => 'home_why_icon4',
        'type' => 'text',
        'std' => 'time-reverse',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '统计数',
        'id' => 'home_total',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（首页底部显示资源与用户数）',
    );
    $ops[] = array(
        'name' => '手机端统计数',
        'id' => 'home_total_m',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '实际数',
        'id' => 'home_total_no',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '不加（勾选后则下面填多少，首页就显示多少。建议不加，如果文章或者用户多的时候，加会拖慢首页加载速度）',
    );
    $ops[] = array(
        'name' => '总资源数',
        'id' => 'total_posts',
        'type' => 'text',
        'std' => '',
        'desc' => '这里填的是一个基数，比如你填500，那么网站显示的是500加上你网站实际的文章数',
    );
    $ops[] = array(
        'name' => 'VIP资源数',
        'id' => 'total_vip_posts',
        'type' => 'text',
        'std' => '',
        'desc' => '这里填的是一个基数，比如你填500，那么网站显示的是500加上你网站实际的文章数',
    );
    $ops[] = array(
        'name' => '总用户数',
        'id' => 'total_users',
        'type' => 'text',
        'std' => '',
        'desc' => '这里填的是一个基数，比如你填500，那么网站显示的是500加上你网站实际的文章数',
    );
    $ops[] = array(
        'name' => 'VIP用户数',
        'id' => 'total_vip_users',
        'type' => 'text',
        'std' => '',
        'desc' => '这里填的是一个基数，比如你填500，那么网站显示的是500加上你网站实际的文章数',
    );
    $ops[] = array(
        'name' => 'Banner',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => 'Banner高度',
        'id' => 'banner_height',
        'type' => 'text',
        'std' => '400',
        'desc' => '默认400',
    );
    $ops[] = array(
        'name' => __('Banner手机端高度'),
        'id' => 'banner_height_mobile',
        'type' => 'text',
        'std' => '300',
        'desc' => '默认300',
    );
    $ops[] = array(
        'name' => 'Banner背景灰度处理',
        'id' => 'banner_dark',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => 'Banner背景图片',
        'id' => 'banner_img',
        'type' => 'upload',
        'std' => '',
        'desc' => '请上传一张高380px的图片，repeat-x模式',
    );
    $ops[] = array(
        'name' => 'Banner视频',
        'id' => 'banner_video',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => 'Banner视频地址',
        'id' => 'banner_video_url',
        'type' => 'upload',
        'std' => '',
        'desc' => '建议mp4格式，控制500k以内最佳，以免影响加载速度',
    );
    $ops[] = array(
        'name' => 'Banner大标题',
        'id' => 'banner_title',
        'type' => 'text',
        'std' => '付费下载资源WordPress主题',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'Banner搜索',
        'id' => 'banner_search',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（开启搜索后不会显示描述与按钮）',
    );
    $ops[] = array(
        'name' => 'Banner搜索分类',
        'id' => 'banner_cats',
        'type' => 'text',
        'std' => '',
        'desc' => '分类ID列表，例如：1,3,8',
    );
    $ops[] = array(
        'name' => 'Banner搜索关键词推荐',
        'id' => 'banner_keywords',
        'type' => 'text',
        'std' => '',
        'desc' => '如果是标签就填标签ID，关键词就填关键词，多个用英文逗号隔开，例如：模板兔,18,23,Erphpdown',
    );
    $ops[] = array(
        'name' => 'Banner小标题',
        'id' => 'banner_desc',
        'type' => 'text',
        'std' => '国内最专业的wordpress建站仿站、二次开发、主题插件定制服务商！',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'Banner按钮',
        'id' => 'banner_btn',
        'type' => 'text',
        'std' => '查看详情',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'Banner链接',
        'id' => 'banner_link',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '幻灯片',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '全屏模式',
        'id' => 'slider_fullwidth',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（图片宽度占整个屏幕）',
    );
    $ops[] = array(
        'name' => '全屏模式高度',
        'id' => 'slider_fullwidth_height',
        'type' => 'text',
        'std' => 400,
        'desc' => '默认400',
    );
    $ops[] = array(
        'name' => '全屏模式手机端高度',
        'id' => 'slider_fullwidth_height_m',
        'type' => 'text',
        'std' => 250,
        'desc' => '默认250',
    );
    $ops[] = array(
        'name' => '幻灯片背景色',
        'id' => 'slider_background',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（仅对非全屏模式有效，用于区分首页默认白色）',
    );
    $ops[] = array(
        'name' => '幻灯片使用文章',
        'id' => 'slider_post',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（幻灯片显示使用指定文章（发布文章时modown属性里勾选幻灯片），下面的5个幻灯片选项则无效）',
    );
    $ops[] = array(
        'name' => '幻灯片标题1',
        'id' => 'slider_title1',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片副标题1',
        'id' => 'slider_desc1',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片按钮文字1',
        'id' => 'slider_btn1',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片链接1',
        'id' => 'slider_link1',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片图片1',
        'id' => 'slider_img1',
        'desc' => '图片尺寸：1200*380',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '幻灯片标题2',
        'id' => 'slider_title2',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片副标题2',
        'id' => 'slider_desc2',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片按钮文字2',
        'id' => 'slider_btn2',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片链接2',
        'id' => 'slider_link2',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片图片2',
        'id' => 'slider_img2',
        'desc' => '图片尺寸：1200*380',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '幻灯片标题3',
        'id' => 'slider_title3',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片副标题3',
        'id' => 'slider_desc3',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片按钮文字3',
        'id' => 'slider_btn3',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片链接3',
        'id' => 'slider_link3',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片图片3',
        'id' => 'slider_img3',
        'desc' => '图片尺寸：1200*380',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '幻灯片标题4',
        'id' => 'slider_title4',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片副标题4',
        'id' => 'slider_desc4',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片按钮文字4',
        'id' => 'slider_btn4',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片链接4',
        'id' => 'slider_link4',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片图片4',
        'id' => 'slider_img4',
        'desc' => '图片尺寸：1200*380',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '幻灯片标题5',
        'id' => 'slider_title5',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片副标题5',
        'id' => 'slider_desc5',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片按钮文字5',
        'id' => 'slider_btn5',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片链接5',
        'id' => 'slider_link5',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '幻灯片图片5',
        'id' => 'slider_img5',
        'desc' => '图片尺寸：1200*380',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '幻灯片右侧栏',
        'id' => 'slider_right',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（不要与全屏模式同时开启，开启右侧栏后幻灯片图片尺寸建议为：895*380）',
    );
    $ops[] = array(
        'name' => '右侧栏使用文章',
        'id' => 'slider_right_post',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（右侧栏显示4个推荐的文章，发布文章时modown属性里勾选推荐；开启后下面的设置无效）',
    );
    $ops[] = array(
        'name' => '右侧栏链接1',
        'id' => 'slider_right_link1',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '右侧栏图片1',
        'id' => 'slider_right_img1',
        'desc' => '图片尺寸：285*180',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '右侧栏链接2',
        'id' => 'slider_right_link2',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '右侧栏图片2',
        'id' => 'slider_right_img2',
        'desc' => '图片尺寸：285*180',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '幻灯片右侧栏小横幅',
        'id' => 'slider_right_banner',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（开启后幻灯片图片尺寸建议为：590*380）',
    );
    $ops[] = array(
        'name' => '右侧栏小横幅链接',
        'id' => 'slider_right_banner_link',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '右侧栏小横幅图片',
        'id' => 'slider_right_banner_img',
        'desc' => '图片尺寸：590*180',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => 'VIP',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '全站隐藏VIP',
        'id' => 'vip_hidden',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（隐藏后，部分非设置性的地方将不会显示VIP功能）',
    );
    $ops[] = array(
        'name' => '首页VIP背景图片',
        'id' => 'vip_bg',
        'desc' => '',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => 'VIP介绍页面背景图',
        'id' => 'vip_bg2',
        'desc' => '',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '直接支付升级',
        'id' => 'vip_just_pay',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（开启后，升级VIP当余额不足时会直接弹出在线支付）',
    );
    $ops[] = array(
        'name' => '仅可支付升级',
        'id' => 'vip_only_pay',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（开启后，无法使用站内余额升级VIP，仅支持在线支付升级）',
    );
    $ops[] = array(
        'name' => '仅可支付升级时单位元',
        'id' => 'vip_only_pay_rmb',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（仅可支付升级时，VIP价格的单位显示为：元）',
    );
    $ops[] = array(
        'name' => '默认余额升级',
        'id' => 'vip_default_pay',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（开启后，升级VIP当余额充足时会自动扣除余额）',
    );
    $ops[] = array(
        'name' => 'VIP介绍页面描述',
        'id' => 'vip_desc',
        'std' => '<p>升级VIP，享受更好的下载体验！</p>',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '普通用户权限',
        'id' => 'vip_no',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '体验VIP权限',
        'id' => 'vip_day',
        'std' => '<ul><li>部分资源免费</li><li>部分资源折扣</li></ul>',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '包月VIP权限',
        'id' => 'vip_month',
        'std' => '<ul><li>部分资源免费</li><li>部分资源折扣</li></ul>',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '包季VIP权限',
        'id' => 'vip_quarter',
        'std' => '<ul><li>部分资源免费</li><li>部分资源折扣</li></ul>',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '包年VIP权限',
        'id' => 'vip_year',
        'std' => '<ul><li>部分资源免费</li><li>部分资源折扣</li></ul>',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '终身VIP权限',
        'id' => 'vip_life',
        'std' => '<ul><li>部分资源免费</li><li>部分资源折扣</li></ul>',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '推荐升级',
        'id' => 'vip_recommend',
        'desc' => '',
        'options' => array(
            0 => '无',
            6 => '体验',
            7 => '包月',
            8 => '包季',
            9 => '包年',
            10 => '终身',

        ),
        'std' => 0,
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '滚动记录',
        'id' => 'vip_order_scroll',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示(在VIP页面显示一个滚动的用户升级VIP记录,吸引用户升级)',
    );
    $ops[] = array(
        'name' => '优势介绍',
        'id' => 'vip_why',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '显示（内容在主题设置 - 首页里填写）',
    );
    $ops[] = array(
        'name' => 'VIP页面常见问题',
        'id' => 'vip_faq',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示',
    );
	
	$ops[] = array(
    'name'    => __('VIP常见问题数量', 'mobantu'),
    'desc'    => __('请输入需要显示的常见问题的数量。', 'mobantu'),
    'id'      => 'vip_faq_count',
    'type'    => 'text',
    'std'     => '2', // 默认值
    'class'   => 'mini',
);

foreach (range(1, _MBT('vip_faq_count')) as $index) {
    $ops[] = array(
        'name'    => __('问题', 'mobantu') . ' ' . $index,
        'desc'    => __('请输入问题', 'mobantu') . ' ' . $index,
        'id'      => 'vip_faq_question' . $index,
        'type'    => 'text',
        'std'     => '',
    );
    $ops[] = array(
        'name'    => __('答案', 'mobantu') . ' ' . $index,
        'desc'    => __('请输入问题答案', 'mobantu') . ' ' . $index,
        'id'      => 'vip_faq_answer' . $index,
        'type'    => 'textarea',
        'std'     => '',
        'settings' => array(
            'rows' => 3,
        ),
    );
}
   
    $ops[] = array(
        'name' => '页面',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '单页面banner显示',
        'id' => 'banner_page',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '单页面banner图片',
        'id' => 'banner_page_img',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '下载页面banner背景颜色',
        'id' => 'banner_download_color_bg',
        'desc' => '默认是#333333',
        'std' => '#333333',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '下载页面banner图片',
        'id' => 'banner_download_img',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '最新发布排除分类ID',
        'id' => 'all_cats_exclude',
        'type' => 'text',
        'std' => '',
        'desc' => '最新发布页面的文章里不显示这些分类的文章，多个用半角英文逗号隔开，例如：1,3,12。',
    );
    $ops[] = array(
        'name' => '投稿权限',
        'desc' => '那种角色权限及以上才能投稿',
        'id' => 'post_tougao_role',
        'options' => array(
            'read' => '订阅者',
            'delete_posts' =>'贡献者',
            'publish_posts' => '作者',
        ),
        'type' => 'select',
    );
    $ops[] = array(
        'name' => 'Ajax无刷新投稿',
        'id' => 'post_tougao_ajax',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用（如果投稿涉及到自定义分类法，请暂时不要启用，否则没法提交自定义分类法的值）',
    );
    $ops[] = array(
        'name' => '投稿间隔',
        'id' => 'post_tougao_time',
        'type' => 'text',
        'std' => '5',
        'desc' => '多少分钟可投稿一次，留空则不限制',
    );
    $ops[] = array(
        'name' => '投稿上传权限',
        'id' => 'tougao_upload',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（前端投稿页面支持上传图片、附件）',
    );
    $ops[] = array(
        'name' => '投稿上传到媒体库',
        'id' => 'tougao_upload_media',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（用户投稿上传的图片、附件进后台媒体库）',
    );
    $ops[] = array(
        'name' => '投稿分类',
        'id' => 'post_tougao_cats',
        'type' => 'text',
        'std' => '',
        'desc' => '允许投稿的分类ID列表，填父分类ID即可（也会显示其子分类），多个用英文逗号隔开，例如：1,4,5',
    );
    $ops[] = array(
        'name' => '投稿免审核',
        'id' => 'post_tougao_submit',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（用户投稿后直接发布，不需要审核，谨慎启用）',
    );
    $ops[] = array(
        'name' => '投稿后可编辑',
        'id' => 'post_tougao_edit',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（用户投稿后可编辑文章）',
    );
    $ops[] = array(
        'name' => '投稿隐藏收费',
        'id' => 'post_tougao_erphpdown',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（投稿隐藏收费选项）',
    );
    $ops[] = array(
        'name' => '发布文章奖励',
        'id' => 'post_tougao_gift',
        'type' => 'text',
        'std' => '',
        'desc' => '请输入一个正数，发布文章后奖励多少erphpdown积分，留空则不启用，可用于前台投稿奖励',
    );
    $ops[] = array(
        'name' => '文章',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '分类页banner显示',
        'id' => 'banner_archive',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '分类页banner背景灰度处理',
        'id' => 'banner_archive_dark',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '分类页banner图片',
        'id' => 'banner_archive_img',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '分类页banner图片高度',
        'id' => 'banner_archive_height',
        'type' => 'text',
        'std' => '',
        'desc' => '留空则默认。填一个数字即可，不需要带px。这里的高度指banner图片的最小高度，由于banner上有标题、描述，还可能带搜索框导致高度变大，所以如需自定义请设置一个合理的高度',
    );
    $ops[] = array(
        'name' => '分类页banner搜索',
        'id' => 'banner_archive_search',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '分类页banner文字居左',
        'id' => 'banner_archive_align_left',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启(建议不要与上面的banner搜索同时开启)',
    );
    $ops[] = array(
        'name' => '分类页显示数量',
        'id' => 'post_category_nums',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启(分类、标签、专题等显示文章数量)',
    );
    $ops[] = array(
        'name' => '分类页置顶文章',
        'id' => 'post_category_sticky',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启(可能会导致分类页面卡顿,请谨慎开启)',
    );
    $ops[] = array(
        'name' => '面包屑导航',
        'id' => 'post_breadcrumb',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '列表项隐藏文字',
        'id' => 'post_text',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（Grid列表只显示一张图片）',
    );
    $ops[] = array(
        'name' => '列表项隐藏底部字段',
        'id' => 'post_metas',
        'desc' => '隐藏',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '列表项标题显示两行',
        'id' => 'post_title',
        'desc' => '开启（默认显示一行，一行并不影响SEO，页面上的标题其实还是完整的，只是通过css隐藏了多余行）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '列表项标题加粗',
        'id' => 'post_title_bold',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '列表项显示分类',
        'id' => 'post_cat',
        'desc' => '显示',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '显示为父分类',
        'id' => 'post_cat_f',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '是（默认是显示其中一个最子级分类，若勾选，则显示所有顶级父分类）',
    );
    $ops[] = array(
        'name' => '显示全部分类',
        'id' => 'post_cat_all',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '是（显示所有分类，包含父分类子分类）',
    );
    $ops[] = array(
        'name' => '分类显示左上角',
        'id' => 'post_cat_lefttop',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '是(列表项的分类显示在图片左上角)',
    );
    $ops[] = array(
        'name' => '列表显示标签',
        'id' => 'post_tag',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示(最多显示三个标签)',
    );
    $ops[] = array(
        'name' => 'Grid列表项显示简介',
        'id' => 'post_excerpt',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（Grid网格列表时显示文章简介）',
    );
    $ops[] = array(
        'name' => '列表显示价格',
        'id' => 'post_price',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（不显示列表页文章的价格）',
    );
    $ops[] = array(
        'name' => '列表价格与分类同行',
        'id' => 'post_price_cat',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用(gird列表项价格与分类显示在同一行,这种情况下建议隐藏底部字段或隐藏列表价格显示)）',
    );

    $ops[] = array(
        'name' => '价格登录显示',
        'id' => 'post_price_logged',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用（<b>请勿随意勾选！</b>不登录不显示文章页的价格，仅对下载模式有效，文章收费模式不要选免登录）',
    );
    $ops[] = array(
        'name' => '列表价格颜色',
        'id' => 'post_price_color',
        'desc' => '文章列表里每个文章右下角的价格背景色,默认是#ababab',
        'std' => '#ababab',
        'type' => 'color',
    );

    $ops[] = array(
        'name' => '角标显示',
        'id' => 'post_vip_free',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（列表页文章的VIP、免费角标）',
    );
    $ops[] = array(
        'name' => '推荐背景色',
        'id' => 'post_recommend_color',
        'desc' => '文章列表里每个文章右上角的推荐背景色,默认与主题色一致',
        'std' => '#ffffff',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '文章作者',
        'id' => 'post_author',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示',
    );
    $ops[] = array(
        'name' => '文章日期',
        'id' => 'post_date',
        'desc' => '显示',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '更新日期',
        'id' => 'post_date_update',
        'desc' => '启用（文章的日期显示为更新日期而不是发布日期）',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '日期显示方式',
        'id' => 'post_date_format',
        'desc' => '',
        'options' => array(
            0 => 'xx前',
            1 => 'Y-m-d',
        ),
        'std' => '0',
        'type' => 'radio',
    );
	$ops[] = array(
        'name' => '阅读全文',
        'id' => 'post_content_all',
        'std' => '',
        'desc' => '开启后文章正文默认只显示一部分，需点击阅读全文来查看全部内容）',
        'type' => 'checkbox',
    );
	
    $ops[] = array(
        'name' => '文章阅读数',
        'id' => 'post_views',
        'desc' => '显示',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章评论数',
        'id' => 'post_comments',
        'desc' => '显示',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章下载数',
        'id' => 'post_downloads',
        'desc' => '开启',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '下载框位置',
        'id' => 'down_position',
        'desc' => '',
        'options' => array(
            'side' => '边栏',
            'top' => '内容上',
            'bottom' => '内容下',
            'sidetop' => '边栏+内容上',
            'sidebottom' => '边栏+内容下',
            'box' => '独立模块',
            'boxbottom' => '独立模块+内容下',
            'boxside' => '独立模块+边栏',
        ),
        'std' => 'side',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '独立模块显示简介',
        'id' => 'post_box_excerpt',
        'desc' => '显示（当有自定义文章字段的时候不会显示）',
        'std' => '',
        'type' => 'checkbox',
    );$ops[] = array(
        'name' => __('正文开头显示特色图片'),
        'id' => 'post_feature',
        'desc' => __('显示（当有设置特色图片时）'),
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => __('正文开头显示自定义字段'),
        'id' => 'post_meta_top',
        'desc' => __('显示'),
        'std' => '',
        'type' => 'checkbox',
    );

    $ops[] = array(
        'name' => '文章视频播放器',
        'id' => 'post_video_player',
        'desc' => '',
        'options' => array(
            'ckplayer' => 'CKPlayer',
            'dplayer' => 'DPlayer',
            'fplayer' => 'FluidPlayer',
        ),
        'std' => 'ckplayer',
        'type' => 'radio',
    );

    $ops[] = array(
        'name' =>  __('文章视频背景'),
        'id' => 'post_video_feature',
        'desc' => __('开启（文章Modown属性里设置的视频，默认显示文章缩略图）'),
        'std' => '',
        'type' => 'checkbox',
    );

    $ops[] = array(
        'name' => '文章顶部视频全宽',
        'id' => 'post_video_fullwidth',
        'desc' => '开启（文章Modown属性里设置的视频，无边栏全宽显示）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章正文video全宽',
        'id' => 'post_video_fullwidth2',
        'desc' => '开启（自动让文章正文内容里的video视频标签全宽且与高度16：9）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章正文iframe全宽',
        'id' => 'post_iframe_fullwidth',
        'desc' => '开启（自动让文章正文内容里的iframe全宽且与高度16：9，即为视频显示样式）',
        'std' => 1,
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章版权申明',
        'id' => 'post_copyright',
        'desc' => '开启',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '自定义版权',
        'id' => 'post_copyright_custom',
        'desc' => '如需要加文章标题链接，请用%post%代替',
        'std' => '原文链接：%post%，转载请注明出处。',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '一键复制推广链接',
        'id' => 'post_copy_aff',
        'desc' => '开启',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '正文图片延迟加载',
        'id' => 'post_lazyload',
        'desc' => '开启（正文里的图片延迟加载显示，可加速文章页面访问速度）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '正文图片点击放大',
        'id' => 'post_fancybox',
        'desc' => '开启（正文里的图片点击可放大，使用的Fancybox弹窗特性）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '正文图片居中显示',
        'id' => 'post_align_center',
        'desc' => '开启（自动将正文里的图片全部居中，启用后可能会影响一些图片布局的显示）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '相册固定方形',
        'id' => 'post_gallery_square',
        'desc' => '开启（由于相册里的图片可能大小不一导致摆乱无章，所以强制显示为正方形）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章标签',
        'id' => 'post_tags',
        'desc' => '开启',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章收藏',
        'id' => 'post_collect',
        'desc' => '开启',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '侧栏演示收藏',
        'id' => 'post_sidefav',
        'desc' => '显示（下载框在边栏时显示演示地址与收藏按钮）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章点赞',
        'id' => 'post_zan',
        'desc' => '开启',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '分享',
        'id' => 'post_share',
        'desc' => '开启',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '分享卡片固定头图',
        'id' => 'post_share_cover_default',
        'desc' => '开启（固定显示下面上传的默认头图，图片地址要是本地网站路径，不要使用外链）',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '分享卡片默认头图',
        'id' => 'post_share_cover_img',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '分享卡片默认LOGO',
        'id' => 'post_share_cover_logo',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '微信分享appid',
        'desc' => '用于分享到微信时显示缩略图，公众号需已认证',
        'id' => 'post_share_weixin_appid',
        'std' => '',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '微信分享appsecret',
        'desc' => '用于分享到微信时显示缩略图，公众号需已认证',
        'id' => 'post_share_weixin_appsecret',
        'std' => '',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '微信分享默认简介',
        'desc' => '用于分享到微信时显示缩略图，公众号需已认证',
        'id' => 'post_share_weixin_desc',
        'std' => '默认简介',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '微信分享默认缩略图',
        'id' => 'post_share_weixin_img',
        'type' => 'upload',
        'std' => '',
        'desc' => '用于分享到微信时显示缩略图，公众号需已认证',
    );
   $ops[] = array(
        'name' => '文章侧栏作者小工具背景图',
        'id' => 'post_side_author_bg',
        'type' => 'upload',
        'std' => '',
        'desc' => '设置侧栏作者小工具背景图',
    );
    $ops[] = array(
        'name' => '打赏',
        'id' => 'post_shang',
        'desc' => '开启',
        'std' => '',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '打赏微信收款码',
        'id' => 'post_shang_weixin',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '打赏支付宝收款码',
        'id' => 'post_shang_alipay',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '上一篇和下一篇文章',
        'id' => 'post_nav',
        'desc' => '开启',
        'std' => '1',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '相关文章',
        'id' => 'post_related',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
	 $ops[] = array(
        'name' => '相关文章是否开启无图模式',
        'id' => 'post_related_noimg',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '相关标题',
        'desc' => '',
        'id' => 'post_related_title',
        'std' => '猜你喜欢',
        'type' => 'text',
    );
	
	
	
    $ops[] = array(
        'name' => '相关数量',
        'desc' => '显示相关文章的数量',
        'id' => 'post_related_num',
        'std' => '6',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '相关限制',
        'desc' => '默认分类限制',
        'id' => 'post_related_in',
        'options' => array(
            'cat' => '分类',
            'tag' => '标签',
            'all' => '分类与标签',
        ),
        'type' => 'select',
    );
    $ops[] = array(
        'name' => '评论显示已购买',
        'id' => 'post_comment_bought',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '评论显示VIP',
        'id' => 'post_comment_vip',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '新窗口打开',
        'id' => 'post_target',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => 'List列表无图时不显示图',
        'id' => 'post_list_img',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（List列表模式时，若文章没有图片，则不显示图片）',
    );
    $ops[] = array(
        'name' => '详情页标题去站名后缀',
        'id' => 'post_title_site',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '搜索文章类型',
        'desc' => '<b>请勿随便填写，不会填写请留空。</b>搜索结果页面显示的文章类型，默认仅显示文章（post），如果需要显示其他类型，请填写，多个用英文逗号隔开，例如post,blog,product',
        'id' => 'post_search_types',
        'std' => '',
        'type' => 'text',
    );
	
	$ops[] = array(
        'name' => __('搜索伪静态'),
        'id' => 'search_rewrite',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('开启搜索伪静态支持'),
    );
	
    $ops[] = array(
        'name' => '文章页宽度适应',
        'id' => 'post_width_auto',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（默认文章页宽度是1200px，如果启用了5列6列等改变了首页、列表页、顶部的宽度，那么文章页跟随）',
    );
     $ops[] = array(
	    'name' => '常见问题', 
	    'id' => 'post_faq', 
	   
	    'type' => 'checkbox', 
	    'std' => '', 
	     'desc' => '开启（在正文下面显示常见问题）', 
    );  
    

$ops[] = array(
    'name'    => __('常见问题数量', 'mobantu'),
    'desc'    => __('请输入需要显示的常见问题的数量。', 'mobantu'),
    'id'      => 'post_faq_count',
    'type'    => 'text',
    'std'     => '3', // 默认值
    'class'   => 'mini',
);

foreach (range(1, _MBT('post_faq_count')) as $index) {
    $ops[] = array(
        'name'    => __('常见问题', 'mobantu') . ' ' . $index,
        'desc'    => __('请输入常见问题', 'mobantu') . ' ' . $index,
        'id'      => 'post_faq_question' . $index,
        'type'    => 'text',
        'std'     => '',
    );
    $ops[] = array(
        'name'    => __('问题答案', 'mobantu') . ' ' . $index,
        'desc'    => __('请输入问题答案', 'mobantu') . ' ' . $index,
        'id'      => 'post_faq_answer' . $index,
        'type'    => 'text',
        'std'     => '',
    );
}



    $ops[] = array(
        'name' => '筛选',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '筛选',
        'id' => 'filter',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '筛选搜索',
        'id' => 'filter_search',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '分类筛选',
        'id' => 'filter_cat',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '子分类父级筛选',
        'id' => 'filter_cat_ancle',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（如果当前分类页是子分类，其父分类也是子分类，则显示其父分类同级分类的筛选。例如层级关系为A——>B,C,D——>B1,B2,B3,C1...，那么进入B1分类时，会显示B,C,D这层筛选）',
    );
    $ops[] = array(
        'name' => '子分类同级筛选',
        'id' => 'filter_cat_brother',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（如果当前分类页是子分类，则显示同级分类的筛选）',
    );
    $ops[] = array(
        'name' => '筛选分类IDs',
        'desc' => '输入分类ID列表，多个用英文半角逗号隔开，例如：1,3,12。<a href="https://www.mobantu.com/7616.html">如何查看ID</a>（此次的筛选用于 最新发布 页面模板，请输入一级分类IDs，如果分类下有二级子分类，会出现二级分类筛选，二级分类可筛选三级分类，最多三级。）',
        'id' => 'filter_cats',
        'std' => '',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '标签筛选',
        'id' => 'filter_tag',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '自动标签',
        'id' => 'filter_tag_auto',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（分类页面自动获取分类下所有标签，开启后可能会影响分类页面加载速度）',
    );
    $ops[] = array(
        'name' => '最大自动标签数',
        'id' => 'filter_tags_auto_count',
        'std' => '20',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '筛选标签IDs',
        'desc' => '输入标签ID列表，多个用英文半角逗号隔开，例如：1,3,12。<a href="https://www.mobantu.com/7616.html">如何查看ID</a>',
        'id' => 'filter_tags',
        'std' => '',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '价格筛选',
        'id' => 'filter_price',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '价格筛选多价格',
        'id' => 'filter_prices',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '启用(不推荐勾选,会导致价格筛选加载慢。勾选就是表示筛选时把多价格模式的文章考虑进来。如果你文章有多价格,可以先设置单价格再设置多价格,这样就算不勾选也可筛选到)',
    );
    $ops[] = array(
        'name' => '价格VIP筛选',
        'id' => 'filter_vip',
        'type' => 'checkbox',
        'std' => '0',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '排序筛选',
        'id' => 'filter_order',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '筛选标题一',
        'desc' => '分类筛选自定义标题',
        'id' => 'filter_cats_title1',
        'std' => '分类',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '筛选标题二',
        'desc' => '二级分类筛选自定义标题',
        'id' => 'filter_cats_title2',
        'std' => '二级分类',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '筛选标题三',
        'desc' => '三级分类筛选自定义标题',
        'id' => 'filter_cats_title3',
        'std' => '三级分类',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '筛选标题四',
        'desc' => '四级分类筛选自定义标题',
        'id' => 'filter_cats_title5',
        'std' => '四级分类',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '筛选标题五',
        'desc' => '标签筛选自定义标题',
        'id' => 'filter_cats_title4',
        'std' => '标签',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '自定义分类法',
        'desc' => '网站需要添加的所有分类法都首先需要在这里填写，填写后系统会自动创建分类法。名称,别名,筛选参数，多个用|隔开。例如：格式,format,fm|大小,size,sz',
        'id' => 'post_taxonomy',
        'std' => '',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '自定义分类法筛选',
        'id' => 'filter_taxonomy',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（请先设置好自定义分类法，再开启）',
    );
    $ops[] = array(
        'name' => '自定义分类法筛选默认显示',
        'id' => 'filter_taxonomy_page',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（最新发布页面与搜索页面默认不显示分类法筛选，只有选择了分类后才会基于分类的设置来显示，开启此项则不选择分类时也会显示筛选）',
    );
    $ops[] = array(
        'name' => '分类法筛选时隐藏空',
        'id' => 'filter_taxonomy_empty',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（自定义分类法筛选时隐藏没有文章的分类法）',
    );
    $ops[] = array(
        'name' => '用户中心',
        'type' => 'heading',
    );
	$ops[] = array(
        'name' => __('移动端用户中心'),
        'id' => 'user_wap_ui',
        'type' => 'checkbox',
        'std' => '',
        'desc' => __('是否开启移动端用户个人中心卡片主页'),
    );
    $ops[] = array(
        'name' => '强制绑定邮箱',
        'id' => 'user_force_email',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用',
    );
    $ops[] = array(
        'name' => '强制绑定手机',
        'id' => 'user_force_mobile',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用（启用前请先在 主题设置-登录 里设置好手机号登录接口）',
    );
    $ops[] = array(
        'name' => '头像上传',
        'id' => 'user_avatar',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '关闭（防止用户乱传图片）',
    );
    $ops[] = array(
        'name' => '头像上传到媒体库',
        'id' => 'user_avatar_media',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '启用（头像图片上传到后台媒体库）',
    );
    $ops[] = array(
        'name' => '随机头像',
        'id' => 'user_random_avatar',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用',
    );
    $ops[] = array(
        'name' => '默认头像',
        'id' => 'user_default_avatar',
        'type' => 'upload',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '默认充值方式',
        'id' => 'recharge_default',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '隐藏（隐藏后则不显示支付接口的充值方式）',
    );
    $ops[] = array(
        'name' => '充值固定金额',
        'id' => 'recharge_price_s',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '固定金额',
        'id' => 'recharge_price',
        'type' => 'text',
        'std' => '1,5,10,50,100',
        'desc' => '输入价格，多个用半角英文逗号隔开，例如：1,5,10,50,100',
    );
    $ops[] = array(
        'name' => '弹窗充值',
        'id' => 'recharge_iframe',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用（仅支持部分支付接口）',
    );
    $ops[] = array(
        'name' => '充值说明',
        'desc' => '用户中心在线充值按钮下面的说明，可加html标签',
        'id' => 'user_charge_tips',
        'std' => '',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => 'VIP说明',
        'desc' => '用户中心升级VIP按钮下面的说明，可加html标签',
        'id' => 'user_vip_tips',
        'std' => '',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => 'VIP记录',
        'id' => 'user_vip_logs',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '显示（在用户中心的升级VIP里显示自己的升级VIP记录）',
    );
    $ops[] = array(
        'name' => '推广',
        'id' => 'user_aff',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '隐藏',
    );
    $ops[] = array(
        'name' => '推广活动图',
        'id' => 'aff_card',
        'type' => 'upload',
        'std' => '',
        'desc' => '网站活动图片（建议图片高度大于宽度），可方便用户生成一个专属推广卡片',
    );
    $ops[] = array(
        'name' => '投稿与销售',
        'id' => 'user_sell',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（显示我的投稿/销售订单）',
    );
    $ops[] = array(
        'name' => '文章瀑布流',
        'id' => 'user_posts_water',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（我的投稿、收藏显示为瀑布流）',
    );

    $ops[] = array(
        'name' => '签到随机奖励',
        'id' => 'checkin_random',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（需要现在Erphpdwon-基础设置里设置每日签到奖励，设置了即为开固定奖励的签到，那么就可以在这里再启用随机奖励）',
    );
    $ops[] = array(
        'name' => '签到随机奖励最小数',
        'id' => 'checkin_gift_min',
        'type' => 'text',
        'std' => '0',
        'desc' => '请输入一个整数',
    );
    $ops[] = array(
        'name' => '签到随机奖励最大数',
        'id' => 'checkin_gift_max',
        'type' => 'text',
        'std' => '0',
        'desc' => '请输入一个整数',
    );
    $ops[] = array(
        'name' => '提现',
        'id' => 'withdraw',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '工单',
        'id' => 'ticket',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '工单限制',
        'id' => 'ticket_new',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启(只有所有老工单都完成了才可以提交新工单)',
    );
    $ops[] = array(
        'name' => '工单待回复通知',
        'id' => 'ticket_reply',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启(待回复的工单也邮件通知管理员,默认只有新工单邮件通知管理员)',
    );
    $ops[] = array(
        'name' => '工单图片上传',
        'id' => 'ticket_img',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（不建议开启，建议大家用外链图片）',
    );
    $ops[] = array(
        'name' => '内容最小高度',
        'id' => 'user_height',
        'type' => 'text',
        'std' => '0',
        'desc' => '请输入一个整数，默认650，如果左侧菜单溢出，可设置一个大于650的数字',
    );
    $ops[] = array(
        'name' => '定制-实名认证（未发布）',
        'id' => 'user_idcard_verify',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '启用（接口购买地址：https://market.aliyun.com/products/57000002/cmapi00035880.html#sku=yuncode2988000001）',
    );
    $ops[] = array(
        'name' => '定制-实名AppCode（未发布）',
        'id' => 'user_idcard_verify_appcode',
        'type' => 'text',
        'std' => '0',
        'desc' => '查看地址：https://market.console.aliyun.com/imageconsole/',
    );
    $ops[] = array(
        'name' => '登录',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '登录Logo',
        'id' => 'logo_login',
        'desc' => '建议尺寸：100*100px 格式：png',
        'std' => 'http://demo.mobantu.com/modown/wp-content/themes/modown/static/img/logo.png',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '登录左侧图',
        'id' => 'login_image',
        'desc' => '例如放一个公众二维码宽300px的竖直广告图',
        'std' => '',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '登录页背景图',
        'id' => 'login_bg',
        'desc' => '主题登录页面的背景图',
        'std' => '',
        'type' => 'upload',
    );


    $ops[] = array(
        'name' => '登录验证码',
        'id' => 'captcha_login',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（建议开启，可防止撞库）',
    );
    $ops[] = array(
        'name' => '强制登录',
        'id' => 'login',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（设置-固定链接需设置伪静态，不能用最上面的一个。登录后才可访问网站内容，开启前请确保有自定义的登录页面Modown Login）',
    );
    $ops[] = array(
        'name' => '注册功能',
        'id' => 'register',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '关闭',
    );
    $ops[] = array(
        'name' => '注册仅社交',
        'id' => 'register_social_only',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（仅可通过社交账号注册，没法通过邮箱注册）',
    );
    $ops[] = array(
        'name' => '注册屏蔽邮箱后缀',
        'id' => 'register_email_suffix',
        'type' => 'textarea',
        'std' => '',
        'desc' => '一行一个后缀域名，例如：linshiyouxiang.net',
    );
    $ops[] = array(
        'name' => '注册允许邮箱后缀',
        'id' => 'register_email_suffix2',
        'type' => 'textarea',
        'std' => '',
        'desc' => '一行一个后缀域名，例如：linshiyouxiang.net，填了允许邮箱后缀，那么上面的屏蔽邮箱后缀就无效了。',
    );
    $ops[] = array(
        'name' => '注册验证码',
        'id' => 'captcha',
        'desc' => '邀请码需安装指定的免费插件，可联系模板兔索要，启用邀请码注册请不要开启社交登录；邮件验证码需安装SMTP插件配置发件',
        'options' => array(
            'none' => '无',
            'image' => '图形验证码',
            'email' => '邮件验证码',
            'invitation' => '邀请码',
        ),
        'std' => 'none',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => '获取邀请码地址',
        'id' => 'invitation_link',
        'type' => 'text',
        'std' => '',
        'desc' => '显示在注册表单处，让用户知道如何获取邀请码',
    );
    $ops[] = array(
        'name' => '购买邀请码注册',
        'id' => 'invitation_buy',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（注册时直接在网站里支付购买邀请码，需要【注册验证码】选邀请码，同时请不要开启QQ、微博、微信等社交登录，详情请看https://www.mobantu.com/9237.html）',
    );
    $ops[] = array(
        'name' => '购买邀请码价格',
        'id' => 'invitation_price',
        'type' => 'text',
        'std' => '',
        'desc' => '元',
    );
    $ops[] = array(
        'name' => '注册协议地址',
        'id' => 'register_policy',
        'type' => 'text',
        'std' => '',
        'desc' => '设置后，注册时用户需阅读并同意注册协议',
    );
    $ops[] = array(
        'name' => '手机号登录',
        'id' => 'oauth_sms',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（阿里云短信接口申请：https://www.aliyun.com/product/sms）',
    );
    $ops[] = array(
        'name' => '优先显示手机号登录',
        'id' => 'oauth_sms_first',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（弹窗登录默认显示手机号登录）',
    );
    $ops[] = array(
        'name' => '阿里云AccessKeyId',
        'id' => 'oauth_aliyun_access_id',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '阿里云AccessKeySecret',
        'id' => 'oauth_aliyun_access_secret',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '阿里云短信签名名称',
        'id' => 'oauth_aliyun_sms_sign',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '阿里云短信模板CODE',
        'id' => 'oauth_aliyun_sms_temp',
        'type' => 'text',
        'std' => '',
        'desc' => '模板类型选【验证码】，模板内容里的变量用${code}，模板内容示例：您的验证码为：${code}，该验证码 5 分钟内有效，请勿泄漏于他人。',
    );
    $ops[] = array(
        'name' => 'QQ登录',
        'id' => 'oauth_qq',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（接口申请：https://connect.qq.com）',
    );
    $ops[] = array(
        'name' => 'qq id',
        'id' => 'oauth_qqid',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'qq key',
        'id' => 'oauth_qqkey',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '微博登录',
        'id' => 'oauth_weibo',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（接口申请：https://open.weibo.com）',
    );
    $ops[] = array(
        'name' => 'weibo id',
        'id' => 'oauth_weiboid',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'weibo key',
        'id' => 'oauth_weibokey',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '微信登录（开发平台）',
        'id' => 'oauth_weixin',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（接口申请：https://open.weixin.qq.com）',
    );
    $ops[] = array(
        'name' => 'weixin id',
        'id' => 'oauth_weixinid',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'weixin srcret',
        'id' => 'oauth_weixinkey',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '微信登录（公众号平台）',
        'id' => 'oauth_weixin_mobile',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（用于微信app里登录，若同时使用开放平台与公众号平台，需先绑定二者，否则用户不同步）',
    );
    $ops[] = array(
        'name' => 'Weixin appid',
        'id' => 'oauth_weixinid_mobile',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => 'Weixin appsrcret',
        'id' => 'oauth_weixinkey_mobile',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '关注公众号登录',
        'id' => 'oauth_weixin_mp',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（需安装插件：https://www.mobantu.com/8259.html 如果已经在使用开放平台的微信登录接口，请暂时不要开启此项，暂时不要开启，暂时不要开启）',
    );
    $ops[] = array(
        'name' => '优先显示公众号登录',
        'id' => 'oauth_weixin_mp_first',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（弹窗登录默认显示关注公众号登录）',
    );
    $ops[] = array(
        'name' => '代理QQ登录',
        'id' => 'oauth_socialogin_qq',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（不可与官方QQ接口混用',
    );
    $ops[] = array(
        'name' => '代理微博登录',
        'id' => 'oauth_socialogin_weibo',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（不可与官方微博接口混用',
    );
    $ops[] = array(
        'name' => '代理微信登录（未发布）',
        'id' => 'oauth_socialogin_weixin',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（不可与官方微博接口混用',
    );
    $ops[] = array(
        'name' => '代理应用 APPID',
        'id' => 'oauth_socialogin_appid',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '代理应用 APPKEY',
        'id' => 'oauth_socialogin_appkey',
        'type' => 'text',
        'std' => '',
        'desc' => '',
    );
    $ops[] = array(
        'name' => '代理应用 接口地址',
        'id' => 'section-oauth_socialogin_api',
        'type' => 'text',
        'std' => '',
        'desc' => '兼容彩虹登录系统，注意最后面带/',
    );
    $ops[] = array(
        'name' => '定制-Google+登录',
        'id' => 'oauth_google',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（需安装插件：https://cn.wordpress.org/plugins/nextend-facebook-connect/，此为定制功能，不建议使用）',
    );
    $ops[] = array(
        'name' => '定制-Facebook登录',
        'id' => 'oauth_facebook',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（需安装插件：https://cn.wordpress.org/plugins/nextend-facebook-connect/，此为定制功能，不建议使用）',
    );
    $ops[] = array(
        'name' => '定制-Twitter登录',
        'id' => 'oauth_twitter',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（需安装插件：https://cn.wordpress.org/plugins/nextend-facebook-connect/，此为定制功能，不建议使用）',
    );
    $ops[] = array(
        'name' => '样式',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '主题主色',
        'desc' => '14种颜色供选择，点击选择你喜欢的颜色，保存后前端展示会有所改变。',
        'id' => 'theme_color',
        'std' => '#ff5f33',
        'type' => 'colorradio',
        'options' => array(
            '#1d1d1d' => 1,
            '#2CDB87' => 2,
            '#00D6AC' => 3,
            '#ff5f33' => 4,
            '#EA84FF' => 5,
            '#FDAC5F' => 6,
            '#FD77B2' => 7,
            '#76BDFF' => 8,
            '#C38CFF' => 9,
            '#FF926F' => 10,
            '#8AC78F' => 11,
            '#C7C183' => 12,
            '#1E88E5' => 13,
            '#6454ef' => 14,
        ),
    );
    $ops[] = array(
        'id' => 'theme_color_custom',
        'std' => '',
        'desc' => '不喜欢上面提供的颜色，你好可以在这里自定义设置，如果不用自定义颜色清空即可（默认不用自定义）',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '主题渐变色',
        'id' => 'theme_color_custom2',
        'std' => '',
        'desc' => '不了解请不要设置。与上面主色相近的稍微浅一点的颜色',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '背景颜色',
        'id' => 'theme_color_bg',
        'std' => '#ffffff',
        'desc' => '默认是白色，不建议自定义背景颜色，会有很多不协调',
        'type' => 'color',
    );
    $ops[] = array(
        'name' => '背景图片',
        'id' => 'theme_body_bg',
        'desc' => '不建议使用背景图片，可能会不协调',
        'std' => '',
        'type' => 'upload',
    );
    $ops[] = array(
        'name' => '背景图片样式',
        'id' => 'theme_body_bg_style',
        'desc' => '',
        'options' => array(
            'default' => '重复平铺',
            'no-repeat' => '展开平铺',
            'top' => '顶部平铺',
            'bottom' => '底部平铺',
        ),
        'std' => 'default',
        'type' => 'radio',

    );
    $ops[] = array(
        'name' => '夜间模式切换',
        'id' => 'theme_night',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启',
    );
    $ops[] = array(
        'name' => '默认夜间模式',
        'id' => 'theme_night_default',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（网站默认使用夜间模式风格）',
    );
    $ops[] = array(
        'name' => '自动夜间模式',
        'id' => 'theme_night_auto',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（19：30-07：30时间段自动使用夜间模式）',
    );
    $ops[] = array(
        'name' => '繁体切换',
        'id' => 'theme_fan',
        'type' => 'checkbox',
        'std' => '1',
        'desc' => '开启（不建议开启，可能会导致有些海外搜索引擎收录的是繁体）',
    );
    $ops[] = array(
        'name' => '默认繁体',
        'id' => 'theme_fan_default',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（不建议开启，除非你的用户群体大多数是用繁体；开启后网站默认使用繁体）',
    );
    $ops[] = array(
        'name' => '字体CDN',
        'id' => 'theme_iconfont_out',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启（主题自带的图标字体使用外链CDN加速，加速网站加载）',
    );
    $ops[] = array(
        'name' => '瀑布流模式',
        'id' => 'waterfall',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启 （不建议开启。如需开启请关闭 图片延迟加载、开启 无限下拉自动分页',
    );
    $ops[] = array(
        'name' => '搜索瀑布流',
        'id' => 'search_waterfall',
        'type' => 'checkbox',
        'std' => '',
        'desc' => '开启 （不建议开启。如需开启请关闭 图片延迟加载、开启 无限下拉自动分页',
    );
    $ops[] = array(
        'name' => __('主导航位置'),
        'id' => 'nav_position',
        'desc' => __('左侧只对分辨率1536px以上页面显示生效'),
        'options' => array(
            '0' => __('顶部'),
            '1' => __('左侧'),
        ),
        'std' => '0',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => __('文章列表显示样式'),
        'id' => 'list_style',
        'desc' => __('默认文章聚合页的显示样式，若标签分类页单独设置了样式，则以单独设置为准'),
        'options' => array(
            'grid' => __('网格Grid'),
            'list' => __('列表List（博客样式）'),
            'list-title' => __('列表List（博客样式）'),
            'list2' => __('两列List（无边栏）'),
            'list3' => __('三列List（无边栏）'),
        ),
        'std' => 'grid',
        'type' => 'radio',
    );
    $ops[] = array(
        'name' => __('Grid文章列数'),
        'id' => 'list_column',
        'desc' => '最大可显示的列数（仅对网格Grid显示样式生效），若有音频Grid样式，请暂时不要使用小5列',
        'options' => array(
            'four' => '4列',
            'four-large' => '大4列',
            'five' => '5列',
            'five-mini' => '小5列',
            'six' => '6列',
            'six-mini' => '小6列',
        ),
        'std' => 'four',
        'type' => 'radio',
    );

    $ops[] = array(
        'name' => '圆角大小',
        'desc' => '主题多处模块的圆角大小，需要带px，默认：5px',
        'id' => 'theme_radius',
        'std' => '5px',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '侧栏宽度',
        'desc' => '文章、页面等右侧栏宽度，默认：300，建议至少300',
        'id' => 'theme_sidebar_width',
        'std' => '300',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '缩略图图片高度',
        'desc' => '文章网格Grid的图片高度，单位px，输入一个数字即可，默认180，如果是正方形，请填285（若最大列数为小6列，默认118，正方形请填188；若最大列数为小5列，默认144，正方形请填228；若最大列数为大4列，默认200，正方形请填320）',
        'id' => 'timthumb_height',
        'std' => '',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '文章正文字号',
        'desc' => 'px，填一个数字即可，不带单位',
        'id' => 'post_content_font_size',
        'std' => '16',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '文章正文手机端字号',
        'desc' => 'px，填一个数字即可，不带单位',
        'id' => 'post_content_font_size_m',
        'std' => '15',
        'type' => 'text',
    );
    $ops[] = array(
        'name' => '自定义CSS样式',
        'desc' => '位于</head>之前，直接写样式代码，不用添加<style>标签',
        'id' => 'css',
        'std' => '',
        'type' => 'textarea',
    );
    $ops[] = array(
        'name' => '广告位',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '首页幻灯片内',
        'id' => 'ad_banner_inner_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_banner_inner',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_banner_inner_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '首页banner/幻灯片下',
        'id' => 'ad_banner_footer_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_banner_footer',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_banner_footer_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '首页下',
        'id' => 'ad_home_footer_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_home_footer',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_home_footer_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '列表上',
        'id' => 'ad_list_header_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_list_header',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_list_header_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '列表下',
        'id' => 'ad_list_footer_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_list_footer',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_list_footer_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章页顶部',
        'id' => 'ad_post_top_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_top',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_top_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章内容上',
        'id' => 'ad_post_header_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_header',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_header_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '独立模块标题下',
        'id' => 'ad_post_box_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_box',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_box_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章正文开头',
        'id' => 'ad_post_content_header_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_content_header',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_content_header_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章正文结尾',
        'id' => 'ad_post_content_footer_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_content_footer',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_content_footer_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章内容下',
        'id' => 'ad_post_footer_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_footer',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_footer_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '文章评论下',
        'id' => 'ad_post_comment_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_post_comment',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_post_comment_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '下载页面',
        'id' => 'ad_erphpdown_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_erphpdown',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_erphpdown_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '全站右上角固定',
        'id' => 'ad_fixed_top_s',
        'std' => '',
        'desc' => '开启',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'desc' => '可添加广告联盟代码或自定义代码',
        'id' => 'ad_fixed_top',
        'std' => '',
        'settings' => array(
            'rows' => 6,
        ),
        'type' => 'textarea',
    );
    $ops[] = array(
        'id' => 'ad_fixed_top_m',
        'std' => '',
        'desc' => '手机端隐藏',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => 'SMTP邮件',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => 'SMTP发邮件',
        'id' => 'smtp',
        'std' => '',
        'desc' => '启用（如果你安装了smtp插件并已配置，可不启用，教程：https://www.mobantu.com/7440.html）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '服务地址',
        'id' => 'smtp_server',
        'type' => 'text',
        'desc' => '例如：smtp.163.com',
    );
    $ops[] = array(
        'name' => '服务协议',
        'id' => 'smtp_ssl',
        'type' => 'text',
        'std' => 'ssl',
        'desc' => '例如：ssl',
    );
    $ops[] = array(
        'name' => '服务端口',
        'id' => 'smtp_port',
        'type' => 'text',
        'std' => '465',
        'desc' => '例如：465',
    );
    $ops[] = array(
        'name' => '账号',
        'id' => 'smtp_account',
        'type' => 'text',
        'std' => '70',
        'desc' => '邮箱账号，例如：noreply@erphp.com',
    );
    $ops[] = array(
        'name' => '密码',
        'id' => 'smtp_pass',
        'type' => 'text',
        'std' => '70',
        'desc' => '一般不是邮箱密码，而是单独的一个授权密码',
    );
    $ops[] = array(
        'name' => '发送者名称',
        'id' => 'from_name',
        'type' => 'text',
        'std' => get_bloginfo('name'),
        'desc' => '一般建议写网站名称',
    );
    $ops[] = array(
        'name' => '扩展',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '团购',
        'id' => 'plugin_tuan',
        'std' => '',
        'desc' => '启用(首次启用需重启主题(切换到别的主题后再切换回来)!不需要再安装Erphpdown团购扩展插件,如已安装请先停掉,数据不影响。启用后可在【工具】 里看到团购列表)',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '禁封用户',
        'id' => 'plugin_loggedin',
        'std' => '',
        'desc' => '启用(首次启用需重启主题(切换到别的主题后再切换回来)!不需要再安装Erphp Loggedin插件,如已安装请先停掉,数据不影响)',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '积分抽奖',
        'id' => 'plugin_draw',
        'std' => '',
        'desc' => '启用(首次启用需重启主题(切换到别的主题后再切换回来)!启用后左侧会出现一个抽奖菜单,需设置下中奖概率与奖励,然后新建页面,正文里写短代码[erphpdown_draw],页面模板建议选全宽页面,如已安装请先停掉,数据不影响',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => 'Sitemap站点地图',
        'id' => 'plugin_sitemap',
        'std' => '',
        'desc' => '启用(基于插件baidu-sitemap-generator,不可一同启用。启用后在【工具】菜单里需要设置)',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '百度推送',
        'id' => 'plugin_fanlysubmit',
        'std' => '',
        'desc' => '启用(基于插件fanlysubmit,不可一同启用。发布文章时可选择推送给百度,启用后在【工具】菜单里需要设置)',
        'type' => 'checkbox',
    );
	$ops[] = array(
        'name' => '冗余数据清理',
        'id' => 'plugin_cleanup',
        'std' => '',
        'desc' => '启用冗余数据清理功能  启用后在【工具】菜单里进入 WP Clean Up ',
        'type' => 'checkbox',
    );
	

    $ops[] = array(
        'name' => 'WordPress优化',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => 'REST API',
        'id' => 'wp_rest_api',
        'std' => '',
        'desc' => '关闭（如果你不需要此功能，建议关闭；若使用的是古藤堡编辑器，请不要关闭）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => 'XMLRPC',
        'id' => 'wp_xmlrpc',
        'std' => '',
        'desc' => '关闭（如果你不需要此功能，建议关闭）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '自动更新',
        'id' => 'wp_auto_update',
        'std' => '',
        'desc' => '关闭',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '重定向wp-login.php',
        'id' => 'redirect_login',
        'std' => '',
        'desc' => '开启（务必确保Modown Login页面已建立。开启后可防止通过wp-login.php撞库）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '禁用?author=',
        'id' => 'hide_author_from',
        'std' => '',
        'desc' => '禁用（禁用后可防止通过?author=批量扫描）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '搜索验证',
        'id' => 'search_captcha',
        'std' => '',
        'desc' => '开启（开启后用户第一次搜索会验证，验证通过后，只要浏览器不关闭，就不会再验证）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '分类链接去category',
        'id' => 'wp_category_remove',
        'std' => '',
        'desc' => '启用（引用的No category base插件的代码，请勿重复安装插件；启用后需要重新保存更改一下固定链接）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '经典编辑器',
        'id' => 'wp_classic_editor',
        'std' => '',
        'desc' => '启用（替换新版编辑器为老版编辑器，引用的Classic Editor插件的代码，请勿重复安装插件）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '经典小工具',
        'id' => 'wp_classic_widgets',
        'std' => '',
        'desc' => '启用（替换新版小工具为老版小工具）',
        'type' => 'checkbox',
    );
    $ops[] = array(
        'name' => '使用教程',
        'type' => 'heading',
    );
    $ops[] = array(
        'name' => '教程地址',
        'type' => 'info',
        'desc' => '<a href="http://www.mobantu.com/7472.html">http://www.mobantu.com/7472.html</a>',
    );
    $ops[] = array(
        'name' => '关于作者',
        'type' => 'info',
        'desc' => '专注WordPress开发7年，提供WordPress建站仿站、二次开发、主题插件定制等服务。',
    );
    
    return $ops;

}
