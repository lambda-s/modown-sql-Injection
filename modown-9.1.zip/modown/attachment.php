<?php
/**
 * The template for displaying attachments
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 */
wp_redirect(home_url());