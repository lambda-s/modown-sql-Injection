<div class="content-none"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="120px" height="120px" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" role="img" aria-hidden="true">
  <circle cx="12" cy="12" r="10"/>
  <line x1="15" y1="9" x2="9" y2="15"/>
  <line x1="9" y1="9" x2="15" y2="15"/>
</svg><div>暂无内容</div></div>