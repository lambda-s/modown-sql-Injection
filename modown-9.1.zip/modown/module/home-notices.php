<div class="banner-notices">
    <div class="container">
        <ul>
        <?php 
            $args = array(
                'post_type'        => 'blog',
                'order'            => 'DESC',
                'showposts'        => 3,
                'ignore_sticky_posts' => 1,
                'tax_query' => array(
                    array('taxonomy' => 'blogs','field' => 'term_id','terms' => _MBT('banner_bottom_notice'))
                )
            );
            
            query_posts($args);
            while (have_posts()) : the_post(); 
                echo '<li><a href="'.get_permalink().'" target="_blank"><span>'.get_the_title().'</span><time>'.get_the_date("Y-m-d").'</time></a></li>';
            endwhile; wp_reset_query(); 
        ?>
        </ul>
    </div>
</div>