<?php 
	global $current_user;
	$mobile = $wpdb->get_var("select mobile from $wpdb->users where ID=".$current_user->ID);
?>
<div class="main">
	<?php 
		if(_MBT('user_force_email') && !$current_user->user_email){
			echo '<div class="container"><div class="warning"><i class="icon icon-smile"></i> '.__('为了确保账号安全，请先绑定邮箱再进行其他操作！','mobantu').'</div></div>';
		}elseif(_MBT('user_force_mobile') && _MBT('oauth_sms') && !$mobile){
			echo '<div class="container"><div class="warning"><i class="icon icon-smile"></i> '.__('为了确保账号安全，请先绑定手机号再进行其他操作！','mobantu').'</div></div>';
		}
	?>
	<?php do_action("modown_main");?>
	<div class="container container-user">
	  <div class="userside">
	    <div class="usertitle"> 
	    	<a href="javascript:;" class="edit-avatar"<?php if(!_MBT('user_avatar')){?> evt="user.avatar.submit"<?php }?> title="<?php if(!_MBT('user_avatar')) echo __('点击修改头像','mobantu'); else echo __('暂未开放上传头像功能','mobantu');?>"><?php echo get_avatar($current_user->ID,50);?></a>
	        <h2><?php echo $current_user->nickname;?></h2>
	        <?php if(!_MBT('user_avatar')){?>
	        <form id="uploadphoto" action="<?php echo get_bloginfo('template_url').'/action/photo.php';?>" method="post" enctype="multipart/form-data" style="display:none;">
	            <input type="file" id="avatarphoto" name="avatarphoto" accept="image/png, image/jpeg">
	        </form>
	    	<?php }?>
	    </div>
	    <div class="usermenus">
	      <ul class="usermenu">
	      	<?php if ( class_exists( 'WooCommerce', false ) ) {?><li class="usermenu-cart"><a href="<?php echo wc_get_page_permalink( 'myaccount' );?>"><i class="icon icon-cart"></i> <?php _e('我的购物','mobantu');?></a></li><?php }?>
	        
	        <li class="usermenu-user <?php if((isset($_GET['action']) && $_GET['action'] == 'info') || !isset($_GET['action'])) echo 'active';?>"><a href="<?php echo add_query_arg('action','info',get_permalink())?>"><i class="icon icon-info"></i> <?php _e('我的资料','mobantu');?></a></li>
	        <?php if(class_exists( 'AnsPress' )){?>
	        <li class="usermenu-question <?php if(isset($_GET['action']) && $_GET['action'] == 'question') echo 'active';?>"><a href="<?php echo add_query_arg('action','question',get_permalink())?>"><i class="icon icon-help"></i> <?php _e('我的提问','mobantu');?></a></li>
	        <li class="usermenu-answer <?php if(isset($_GET['action']) && $_GET['action'] == 'answer') echo 'active';?>"><a href="<?php echo add_query_arg('action','answer',get_permalink())?>"><i class="icon icon-comment"></i> <?php _e('我的回答','mobantu');?></a></li>
	        <?php }?>
	        <?php if(function_exists('QAPress_scripts')){?>
	        <li class="usermenu-faqs <?php if(isset($_GET['action']) && $_GET['action'] == 'faq') echo 'active';?>"><a href="<?php echo add_query_arg('action','faq',get_permalink())?>"><i class="icon icon-help"></i> <?php _e('我的提问','mobantu');?></a></li>
	        <?php }?>
			<li class="usermenu-comments <?php if(isset($_GET['action']) && $_GET['action'] == 'comment') echo 'active';?>"><a href="<?php echo add_query_arg('action','comment',get_permalink())?>"><i class="icon icon-comments"></i> <?php _e('我的评论','mobantu');?></a></li>
			<?php if(_MBT('user_sell')){?>
			<li class="usermenu-post <?php if(isset($_GET['action']) && $_GET['action'] == 'post') echo 'active';?>"><a href="<?php echo add_query_arg('action','post',get_permalink())?>"><i class="icon icon-posts"></i> <?php _e('我的投稿','mobantu');?></a></li>
			<?php }?>
			<?php if(_MBT('post_collect') || _MBT('post_sidefav')){?><li class="usermenu-collect <?php if(isset($_GET['action']) && $_GET['action'] == 'collect') echo 'active';?>"><a href="<?php echo add_query_arg('action','collect',get_permalink())?>"><i class="icon icon-stars"></i> <?php _e('我的收藏','mobantu');?></a></li><?php }?>
			<?php if(_MBT('ticket')){?>
			<li class="usermenu-ticket <?php if(isset($_GET['action']) && $_GET['action'] == 'ticket') echo 'active';?>"><a href="<?php echo add_query_arg('action','ticket',get_permalink())?>"><i class="icon icon-temp-new"></i> <?php _e('提交工单','mobantu');?></a></li>
			<li class="usermenu-tickets <?php if(isset($_GET['action']) && $_GET['action'] == 'tickets') echo 'active';?>"><a href="<?php echo add_query_arg('action','tickets',get_permalink())?>"><i class="icon icon-temp"></i> <?php _e('我的工单','mobantu');?></a></li>
			<?php }?>
	        <li class="usermenu-signout"><a href="<?php echo wp_logout_url(get_bloginfo("url"));?>"><i class="icon icon-signout"></i> <?php _e('安全退出','mobantu');?></a></li>
	      </ul>
	    </div>
	  </div>
	  <div class="content" id="contentframe">
	    <div class="user-main">
	      <?php if(isset($_GET['action']) && $_GET['action'] == 'comment'){ ?>
	          <?php 
			  	$perpage = 10;
				if (!get_query_var('paged')) {
					$paged = 1;
				}else{
					$paged = esc_sql(get_query_var('paged'));
				}
				$total_comment = $wpdb->get_var("select count(comment_ID) from $wpdb->comments where comment_approved='1' and user_id=".$current_user->ID);
				$pagess = ceil($total_comment / $perpage);
				$offset = $perpage*($paged-1);
				$results = $wpdb->get_results("select $wpdb->comments.comment_ID,$wpdb->comments.comment_post_ID,$wpdb->comments.comment_content,$wpdb->comments.comment_date,$wpdb->posts.post_title from $wpdb->comments left join $wpdb->posts on $wpdb->comments.comment_post_ID = $wpdb->posts.ID where $wpdb->comments.comment_approved='1' and $wpdb->comments.user_id=".$current_user->ID." order by $wpdb->comments.comment_date DESC limit $offset,$perpage");
				if($results){
			  ?>
	          <ul class="user-commentlist">
	            <?php foreach($results as $result){?>
	          	<li><time><?php echo $result->comment_date;?></time><p class="note"><?php echo $result->comment_content;?></p><p class="text-muted"><?php _e('文章：','mobantu');?><a target="_blank" href="<?php echo get_permalink($result->comment_post_ID);?>"><?php echo $result->post_title;?></a></p></li>
	            <?php }?>
	          </ul>
	          <?php MBThemes_custom_paging($paged,$pagess);?>
	          <?php }else{?>
	          <div class="user-ordernone"><h6><?php _e('暂无记录','mobantu');?></h6></div>
	          <?php }?>
	      <?php }elseif(isset($_GET['action']) && $_GET['action'] == 'post'){
	      		$status = 'publish';
	      		if(isset($_GET['status'])){
	      			$status = $_GET['status'];
	      		}
	      		$totallists = $wpdb->get_var("SELECT count(ID) FROM $wpdb->posts WHERE post_author=".$current_user->ID." and post_status='".$status."' and post_type='post'");
				$perpage = 16;
				$pagess = ceil($totallists / $perpage);
				if (!get_query_var('paged')) {
					$paged = 1;
				}else{
					$paged = esc_sql(get_query_var('paged'));
				}
				$offset = $perpage*($paged-1);
				$results = $wpdb->get_results("SELECT * FROM $wpdb->posts where post_author=".$current_user->ID." and post_status='".$status."' and post_type='post' order by post_date DESC limit $offset,$perpage");
	      ?>
	      		<div class="user-postnav">
	      	  		<?php _e('状态：','mobantu');?><a href="<?php echo add_query_arg(array("action"=>'post',"status"=>'publish',"paged"=>1),get_permalink(MBThemes_page("template/user.php")));?>" class="<?php if(!isset($_GET['status']) || (isset($_GET['status']) && $_GET['status'] == 'publish')) echo 'active';?>"><?php _e('已发布','mobantu');?></a><a href="<?php echo add_query_arg(array("action"=>'post',"status"=>'pending',"paged"=>1),get_permalink(MBThemes_page("template/user.php")));?>" class="<?php if(isset($_GET['status']) && $_GET['status'] == 'pending') echo 'active';?>"><?php _e('审核中','mobantu');?></a><a href="<?php echo add_query_arg(array("action"=>'post',"status"=>'draft',"paged"=>1),get_permalink(MBThemes_page("template/user.php")));?>" class="<?php if(isset($_GET['status']) && $_GET['status'] == 'draft') echo 'active';?>"><?php _e('草稿','mobantu');?></a>
	      	  	</div>
	      	  <?php if($results) {?>
	      	  	<div class="user-gridlist<?php if(_MBT('user_posts_water')) echo ' waterfall';?> clearfix">
	            <?php foreach($results as $result){?>
	          	<div class="item clearfix">
	          		<a href="<?php if(!isset($_GET['status']) || (isset($_GET['status']) && $_GET['status'] == 'publish')) the_permalink($result->ID);?>" target="_blank"><img src="<?php echo MBThemes_thumbnail_post($result->ID,_MBT('user_posts_water')?'1':'0');?>"></a>
	          		<h4><a href="<?php if(!isset($_GET['status']) || (isset($_GET['status']) && $_GET['status'] == 'publish')) the_permalink($result->ID);?>" target="_blank"><?php echo get_the_title($result->ID);?></a></h4>
	          		<time><span><?php _e('投稿于：','mobantu');?></span><?php echo $result->post_date;?></time>
	          		<?php if(_MBT('post_tougao_edit')){ echo '<a class="edit" href="'.add_query_arg('post_id',$result->ID,get_permalink(MBThemes_page("template/tougao.php"))).'" target="_blank">'.__('编辑','mobantu').'</a>';}?>
	          	</div>
	            <?php }?>
	            </div>
	          <?php MBThemes_custom_paging($paged,$pagess);?>
	          <?php }else{?>
	          <div class="user-ordernone"><h6><?php _e('暂无记录','mobantu');?></h6></div>
	          <?php }?>
	      <?php }elseif(isset($_GET['action']) && $_GET['action'] == 'faq'){
	      		$totallists = $wpdb->get_var("SELECT count(ID) FROM $wpdb->posts WHERE post_author=".$current_user->ID." and post_status='publish' and post_type='qa_post'");
				$perpage = 10;
				$pagess = ceil($totallists / $perpage);
				if (!get_query_var('paged')) {
					$paged = 1;
				}else{
					$paged = esc_sql(get_query_var('paged'));
				}
				$offset = $perpage*($paged-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->posts where post_author=".$current_user->ID." and post_status='publish' and post_type='qa_post' order by post_date DESC limit $offset,$perpage");
	      ?>
	      	  <?php if($lists) {?>
	          <ul class="user-postlist">
	          	<?php foreach($lists as $value){ $post = get_post($value->ID); setup_postdata($post);?>
	          	<li>
					<h2><a target="_blank" href="<?php the_permalink($value->ID);?>"><?php the_title();?></a></h2>
					<p class="note" style="height: auto;"><?php echo MBThemes_get_excerpt();?></p>
					<p class="text-muted"><?php echo $value->post_date;?></p>
				</li>
	          	<?php }?>
	          </ul>
	          <?php MBThemes_custom_paging($paged,$pagess);?>
	          <?php }else{?>
	          <div class="user-ordernone"><h6><?php _e('暂无记录','mobantu');?></h6></div>
	          <?php }?>
	      <?php }elseif(isset($_GET['action']) && $_GET['action'] == 'question'){
	      		$totallists = $wpdb->get_var("SELECT count(ID) FROM $wpdb->posts WHERE post_author=".$current_user->ID." and post_status='publish' and post_type='question'");
				$perpage = 10;
				$pagess = ceil($totallists / $perpage);
				if (!get_query_var('paged')) {
					$paged = 1;
				}else{
					$paged = esc_sql(get_query_var('paged'));
				}
				$offset = $perpage*($paged-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->posts where post_author=".$current_user->ID." and post_status='publish' and post_type='question' order by post_date DESC limit $offset,$perpage");
	      ?>
	      	  <?php if($lists) {?>
	          <ul class="user-postlist">
	          	<?php foreach($lists as $value){ $post = get_post($value->ID); setup_postdata($post);?>
	          	<li>
					<h2><a target="_blank" href="<?php the_permalink($value->ID);?>"><?php the_title();?></a></h2>
					<p class="note" style="height: auto;"><?php echo MBThemes_get_excerpt();?></p>
					<p class="text-muted"><?php echo $value->post_date;?></p>
				</li>
	          	<?php }?>
	          </ul>
	          <?php MBThemes_custom_paging($paged,$pagess);?>
	          <?php }else{?>
	          <div class="user-ordernone"><h6><?php _e('暂无记录','mobantu');?></h6></div>
	          <?php }?>
	      <?php }elseif(isset($_GET['action']) && $_GET['action'] == 'answer'){
	      		$totallists = $wpdb->get_var("SELECT count(ID) FROM $wpdb->posts WHERE post_author=".$current_user->ID." and post_status='publish' and post_type='answer'");
				$perpage = 10;
				$pagess = ceil($totallists / $perpage);
				if (!get_query_var('paged')) {
					$paged = 1;
				}else{
					$paged = esc_sql(get_query_var('paged'));
				}
				$offset = $perpage*($paged-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->posts where post_author=".$current_user->ID." and post_status='publish' and post_type='answer' order by post_date DESC limit $offset,$perpage");
	      ?>
	      	  <?php if($lists) {?>
	          <ul class="user-commentlist">
	          	<?php foreach($lists as $value){ $post = get_post($value->ID); setup_postdata($post);?>
	          	<li>
	          		<time><?php echo $value->post_date;?></time>
					<p class="note" style="height: auto;"><?php echo MBThemes_get_excerpt();?></p>
					<p class="text-muted"><?php _e('问题：','mobantu');?><a target="_blank" href="<?php echo get_permalink($value->post_name);?>"><?php echo $value->post_title;?></a></p>
				</li>
	          	<?php }?>
	          </ul>
	          <?php MBThemes_custom_paging($paged,$pagess);?>
	          <?php }else{?>
	          <div class="user-ordernone"><h6><?php _e('暂无记录','mobantu');?></h6></div>
	          <?php }?>
	      <?php }elseif(isset($_GET['action']) && $_GET['action'] == 'collect'){ ?>
	          <?php 
			  	$perpage = 16;
				if (!get_query_var('paged')) {
					$paged = 1;
				}else{
					$paged = esc_sql(get_query_var('paged'));
				}
				$total_collect = $wpdb->get_var("select count(ID) from ".$wpdb->prefix."collects where user_id=".$current_user->ID);
				$pagess = ceil($total_collect / $perpage);
				$offset = $perpage*($paged-1);
				$results = $wpdb->get_results("select * from ".$wpdb->prefix."collects where user_id=".$current_user->ID." order by create_time DESC limit $offset,$perpage");
				if($results){
			  ?>
	          <div class="user-gridlist<?php if(_MBT('user_posts_water')) echo ' waterfall';?> clearfix">
	            <?php foreach($results as $result){?>
	          	<div class="item clearfix">
	          		<a href="<?php the_permalink($result->post_id);?>" target="_blank"><img src="<?php echo MBThemes_thumbnail_post($result->post_id,_MBT('user_posts_water')?'1':'0');?>"></a>
	          		<h4><a href="<?php the_permalink($result->post_id);?>" target="_blank"><?php echo get_the_title($result->post_id);?></a></h4>
	          		<time><span><?php _e('收藏于：','mobantu');?></span><?php echo $result->create_time;?></time>
	          		<p class="text-muted"><a href="javascript:;" class="article-collect" data-id="<?php echo $result->post_id;?>"><?php _e('取消收藏','mobantu');?></a></p>
	          	</div>
	            <?php }?>
	          </div>
	          <?php MBThemes_custom_paging($paged,$pagess);?>
	          <?php }else{?>
	          <div class="user-ordernone"><h6><?php _e('暂无记录','mobantu');?></h6></div>
	          <?php }?>
	      <?php }elseif(isset($_GET['action']) && $_GET['action'] == 'ticket'){ 
			      	modown_ticket_new_html();
			    }elseif(isset($_GET['action']) && $_GET['action'] == 'tickets'){ 
			      	modown_ticket_list_html();
			    }else{ ?>
	          <form style="margin-bottom: 30px">
	            <ul class="user-meta">
	              <li>
	                <label><?php _e('用户名','mobantu');?></label>
	                <?php echo $current_user->user_login;?> </li>
	              <li>
	                <label><?php _e('注册时间','mobantu');?></label>
	                <?php echo get_date_from_gmt( $current_user->user_registered ); ?>
	                </li>
	              <li>
	                <label><?php _e('昵称','mobantu');?></label>
	                <input type="text" class="form-control" name="nickname" value="<?php echo $current_user->nickname;?>">
	              </li>
	              <li>
	                <label>QQ</label>
	                <input type="text" class="form-control" name="qq" value="<?php echo get_user_meta($current_user->ID, 'qq', true);?>">
	              </li>
	              <li>
	                <label><?php _e('个人简介','mobantu');?></label>
	                <textarea class="form-control" name="description" rows="5" style="height: 80px;padding: 5px 10px;"><?php echo $current_user->description;?></textarea>
	              </li>
	              <li>
	                <input type="button" evt="user.data.submit" class="btn btn-primary" value="<?php _e('修改资料','mobantu');?>">
	                <input type="hidden" name="action" value="user.edit">
	              </li>
	            </ul>
	          </form>
	          <form id="bind-email" style="margin-bottom: 30px;<?php if(_MBT('user_force_email') && !$current_user->user_email) echo 'border: 2px dashed #f58b36;border-radius: 5px;padding-top: 17px';?>">
	            <ul class="user-meta">
	            <li>
	                <label><?php _e('邮箱','mobantu');?></label>
	                <input type="email" class="form-control" name="email" value="<?php echo $current_user->user_email;?>">
	              </li>
	              <li>
	                <label><?php _e('验证码','mobantu');?></label>
	                <input type="text" class="form-control" name="captcha" value="" style="width:150px;display:inline-block"> <a evt="user.email.captcha.submit" style="display:inline-block;font-size: 13px;cursor: pointer;"><i class="icon icon-mail"></i> <?php _e('获取验证码','mobantu');?></a>
	              </li>
	              <li>
	                <input type="button" evt="user.email.submit" class="btn btn-primary" value="<?php if($current_user->user_email) echo __('修改邮箱','mobantu'); else echo __('绑定邮箱','mobantu');?>">
	                <input type="hidden" name="action" value="user.email">
	              </li>               
	             </ul>
	          </form>
	          <?php if(_MBT('oauth_sms')){
	          	$mobile = $wpdb->get_var("select mobile from $wpdb->users where ID=".$current_user->ID);
	          	?>
	          <form style="margin-bottom: 30px;<?php if(_MBT('user_force_mobile') && !$mobile) echo 'border: 2px dashed #f58b36;border-radius: 5px;padding-top: 17px';?>">
	            <ul class="user-meta">
	            <li>
	                <label><?php _e('手机号','mobantu');?></label>
	                <input type="text" class="form-control" name="mobile" value="<?php echo $mobile;?>">
	              </li>
	              <li>
	                <label><?php _e('验证码','mobantu');?></label>
	                <input type="text" class="form-control" name="captcha" value="" style="width:150px;display:inline-block"> <a evt="user.mobile.captcha.submit" style="display:inline-block;font-size: 13px;cursor: pointer;"><i class="icon icon-mobile"></i> <?php _e('获取验证码','mobantu');?></a>
	              </li>
	              <li>
	                <input type="button" evt="user.mobile.submit" class="btn btn-primary" value="<?php _e('修改手机号','mobantu');?>">
	                <input type="hidden" name="action" value="user.mobile">
	              </li>               
	             </ul>
	          </form>
	          <?php }?>
	          <form style="margin-bottom: 30px">
	            <ul class="user-meta">
	              <li>
	                <label><?php _e('新密码','mobantu');?></label>
	                <input type="password" class="form-control" name="password">
	              </li>
	              <li>
	                <label><?php _e('重复新密码','mobantu');?></label>
	                <input type="password" class="form-control" name="password2">
	              </li>
	              <li>
	                <input type="button" evt="user.data.submit" class="btn btn-primary" value="<?php _e('修改密码','mobantu');?>">
	                <input type="hidden" name="action" value="user.password">
	              </li>
	            </ul>
	          </form>
	          <?php if(_MBT('oauth_socialogin_weixin') || _MBT('oauth_socialogin_weibo') || _MBT('oauth_socialogin_qq') || _MBT('oauth_qq') || _MBT('oauth_weibo') || (_MBT('oauth_weixin') || (_MBT('oauth_weixin_mobile') && modown_is_mobile())) || _MBT('oauth_weixin_mp') && function_exists('ews_login')){?>
	          	<ul class="user-meta">
				<li class="secondItem">
					<?php 
						$userSocial = $wpdb->get_row("select qqid,sinaid,weixinid from $wpdb->users where ID=".$current_user->ID);
					?>
					<label><?php _e('社交账号绑定','mobantu');?></label>
					<?php if(_MBT('oauth_weixin_mp') && function_exists('ews_login')){?>
					<section class="item">
						<section class="platform weixin">
							<i class="icon icon-weixin"></i>
						</section>
						<section class="platform-info">
							<p class="name"><?php _e('微信','mobantu');?></p><p class="status">
							<?php if($userSocial->weixinid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="weixin"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
							<a href="javascript:;" evt="user.social.ews.bind"><?php _e('立即绑定','mobantu');?></a>
							<div class="erphp-weixin-scan-bind"><?php echo do_shortcode('[erphp_weixin_scan_bind type=1]');?></div>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
					<?php if(_MBT('oauth_weixin') || (_MBT('oauth_weixin_mobile') && modown_is_mobile())){?>
					<section class="item">
						<section class="platform weixin">
							<i class="icon icon-weixin"></i>
						</section>
						<section class="platform-info">
							<p class="name"><?php _e('微信','mobantu');?></p><p class="status">
							<?php if($userSocial->weixinid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="weixin"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
								<?php if(modown_is_mobile() && _MBT('oauth_weixin_mobile')){?>
								<a class="login-weixin" href="https://open.weixin.qq.com/connect/oauth2/authorize?appid=<?php echo _MBT('oauth_weixinid_mobile');?>&redirect_uri=<?php echo home_url();?>/oauth/weixin/bind.php&response_type=code&scope=snsapi_userinfo&state=MBT_weixin_login#wechat_redirect" rel="nofollow"><?php _e('立即绑定','mobantu');?></a>
								<?php }elseif(_MBT('oauth_weixin')){?>
								<a href="https://open.weixin.qq.com/connect/qrconnect?appid=<?php echo _MBT('oauth_weixinid');?>&redirect_uri=<?php bloginfo("url")?>/oauth/weixin/bind.php&response_type=code&scope=snsapi_login&state=MBT_weixin_login#wechat_redirect" ><?php _e('立即绑定','mobantu');?></a>
								<?php }?>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
					<?php if(_MBT('oauth_socialogin_weixin')){?>
					<section class="item">
						<section class="platform weixin">
							<i class="icon icon-weixin"></i>
						</section>
						<section class="platform-info">
							<p class="name"><?php _e('微信','mobantu');?></p><p class="status">
							<?php if($userSocial->weixinid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="weixin"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
							<a href="<?php bloginfo("url");?>/oauth/socialogin?act=bind&type=wx&rurl=<?php echo get_permalink(MBThemes_page('template/user.php'));?>?action=info" ><?php _e('立即绑定','mobantu');?></a>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
					<?php if(_MBT('oauth_socialogin_weibo')){?>
					<section class="item">
						<section class="platform weibo">
							<i class="icon icon-weibo"></i>
						</section>
						<section class="platform-info">
							<p class="name"><?php _e('微博','mobantu');?></p><p class="status">
							<?php if($userSocial->sinaid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="weibo"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
							<a href="<?php bloginfo("url");?>/oauth/socialogin?act=bind&type=sina&rurl=<?php echo get_permalink(MBThemes_page('template/user.php'));?>?action=info" ><?php _e('立即绑定','mobantu');?></a>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
					<?php if(_MBT('oauth_socialogin_qq')){?>
					<section class="item">
						<section class="platform qq">
							<i class="icon icon-qq"></i>
						</section>
						<section class="platform-info">
							<p class="name">QQ</p><p class="status">
							<?php if($userSocial->qqid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="qq"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
							<a href="<?php bloginfo("url");?>/oauth/socialogin?act=bind&type=qq&rurl=<?php echo get_permalink(MBThemes_page('template/user.php'));?>?action=info" ><?php _e('立即绑定','mobantu');?></a>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
					<?php if(_MBT('oauth_weibo')){?>
					<section class="item">
						<section class="platform weibo">
							<i class="icon icon-weibo"></i>
						</section>
						<section class="platform-info">
							<p class="name"><?php _e('微博','mobantu');?></p><p class="status">
							<?php if($userSocial->sinaid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="weibo"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
							<a href="<?php bloginfo("url");?>/oauth/weibo/bind.php?rurl=<?php echo get_permalink(MBThemes_page('template/user.php'));?>?action=info" ><?php _e('立即绑定','mobantu');?></a>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
					<?php if(_MBT('oauth_qq')){?>
					<section class="item">
						<section class="platform qq">
							<i class="icon icon-qq"></i>
						</section>
						<section class="platform-info">
							<p class="name">QQ</p><p class="status">
							<?php if($userSocial->qqid){?>
							<span><?php _e('已绑定','mobantu');?></span>
							<a href="javascript:;" evt="user.social.cancel" data-type="qq"><?php _e('取消绑定','mobantu');?></a>
							<?php }else{?>
							<a href="<?php bloginfo("url");?>/oauth/qq/bind.php?rurl=<?php echo get_permalink(MBThemes_page('template/user.php'));?>?action=info" ><?php _e('立即绑定','mobantu');?></a>
							<?php }?>
							</p>
						</section>
					</section>
					<?php }?>
				</li>
				</ul>
				<?php }?>
			  <?php }?>
	    </div>
	    <div class="user-tips"></div>
	  </div>
	</div>
	<script src="<?php bloginfo("template_url")?>/static/js/user.js"></script>
</div>