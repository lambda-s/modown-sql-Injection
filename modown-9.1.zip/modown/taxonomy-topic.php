<?php get_header();$tag_slug = get_query_var('topic');$tag = get_term_by('slug',$tag_slug,'topic');
$style = get_term_meta($tag->term_id,'style',true);$tag_class = 'grids'; 
if($style == 'list') $tag_class = 'lists';
elseif($style == 'grid') $tag_class = 'grids';
elseif($style == 'grid-audio') $cat_class = 'grids';
elseif($style == 'list2') $cat_class = 'lists cols-two';
elseif($style == 'list3') $cat_class = 'lists cols-three';
elseif($style == 'list-title') $cat_class = 'lists cols-title';
else{
    $style = _MBT('list_style');if($style == 'list') $tag_class = 'lists';elseif($style == 'list2') $cat_class = 'lists cols-two'; elseif($style == 'list3') $cat_class = 'lists cols-three';elseif($style == 'list-title') $cat_class = 'lists cols-title';
}
$banner_archive_img = '';
$banner_img = get_term_meta($tag->term_id,'banner_img',true);
if($banner_img){
    $banner_archive_img = $banner_img;
}else{
    if(_MBT('banner_archive_img')){
        $banner_archive_img = _MBT('banner_archive_img');
    }
}
?>
<div class="banner-archive" <?php if($banner_archive_img){?> style="background-image: url(<?php echo $banner_archive_img;?>);" <?php }?>>
	<div class="container">
		<h1 class="archive-title"><?php single_tag_title();if(_MBT('post_category_nums')) echo '<span>'.MBThemes_term_post_count('topic', $tag->term_id).__('篇','mobantu').'</span>'; ?></h1>
		<p class="archive-desc"><?php echo trim(strip_tags(tag_description()));?></p>
	</div>
</div>
<div class="main">
	<?php do_action("modown_main");?>
	<div class="container clearfix">
		<?php if($style == 'list') echo '<div class="content-wrap"><div class="content">';?>
		<?php MBThemes_ad('ad_list_header');?>
		<div id="posts" class="posts <?php echo $tag_class;?> <?php if(MBTheme_waterfall() && $style != 'list') echo 'waterfall';?> clearfix">
			<?php 
				$ccc = 'content';if($style == 'list') $ccc = 'content-list';elseif($style == 'grid-audio') $ccc = 'content-audio';elseif($style == 'list-title') $ccc = 'content-list-title';
				if ( have_posts() ){
					while ( have_posts() ) : the_post(); 
					get_template_part( 'module/'.$ccc );
					endwhile; wp_reset_query(); 
				}else{
                    get_template_part( 'module/none' );
                }
			?>
		</div>
		<?php MBThemes_paging();?>
		<?php MBThemes_ad('ad_list_footer');?>
		<?php if($style == 'list') {echo '</div></div>';get_sidebar();}?>
	</div>
</div>
<?php get_footer();?>